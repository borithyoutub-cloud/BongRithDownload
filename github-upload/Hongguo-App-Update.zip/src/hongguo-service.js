const fs = require('node:fs');
const fsp = require('node:fs/promises');
const Module = require('node:module');
const path = require('node:path');
const http = require('node:http');
const https = require('node:https');
const { spawn } = require('node:child_process');

/**
 * Allows openhongguo's ESM entrypoint to require('./dist/wasm_exec.js') under
 * Node 20.x / Electron 33 where parent package.json sets "type": "module".
 */
function ensureOpenhongguoWasmShim() {
  if (Module._hongguoWasmShimmed) return;
  Module._hongguoWasmShimmed = true;
  const origJs = Module._extensions['.js'];
  Module._extensions['.js'] = function patchedJsLoader(mod, filename) {
    if (filename && filename.includes('openhongguo') && filename.endsWith('wasm_exec.js')) {
      return mod._compile(fs.readFileSync(filename, 'utf8'), filename);
    }
    return origJs.call(this, mod, filename);
  };
}

const HONGGUO_BASE = 'https://hongguoduanju.com';
const DEFAULT_HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  Referer: `${HONGGUO_BASE}/`,
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
};

const NUMERIC_ID_RE = /^\d{10,32}$/;
const URL_LIKE_RE =
  /^(?:https?:\/\/|(?:www\.|[a-z0-9-]+\.(?:com|net|org|cn|tv|io|me|cc|co|app|xyz|top|info|biz|vip|wang|la|ly|be|gl|gg|uk|jp|kr|kh))(?:\/|\?|#|$))/i;

const WEB_CATEGORIES = [
  { id: 'real-drama', nameKm: 'រឿងភាគមនុស្សពិត', nameZh: '真人剧' },
  { id: 'comic-drama', nameKm: 'រឿងគំនូរជីវចល', nameZh: '漫剧' },
  { id: 'ai-drama', nameKm: 'រឿង AI', nameZh: 'AI剧' },
  { id: 'comic', nameKm: 'តុក្កតា', nameZh: '动漫' },
];

const NEW_UPDATE_TYPES = [
  { id: 'new-calendar', nameKm: 'ទើបចេញថ្មីថ្ងៃនេះ 🔥' },
  { id: 'latest-drama', nameKm: 'រឿងភាគទើបអាប់ដេត' },
  { id: 'latest-comic', nameKm: 'គំនូរជីវចលថ្មី' },
  { id: 'latest-ai', nameKm: 'រឿង AI ថ្មី' },
];

function createAppError(code, message, cause) {
  const err = new Error(message);
  err.code = code;
  if (cause) err.cause = cause;
  return err;
}

function resolveFfmpegPath() {
  let ffmpegBin = require('ffmpeg-static');
  if (ffmpegBin && ffmpegBin.includes('app.asar')) {
    ffmpegBin = ffmpegBin.replace('app.asar', 'app.asar.unpacked');
  }
  return ffmpegBin;
}

function safeFileName(name, fallback = 'hongguo_video') {
  const cleaned = String(name || '')
    .replace(/[\\/:*?"<>|\x00-\x1f]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^\.+|\.+$/g, '')
    .slice(0, 80)
    .trim();
  return cleaned || fallback;
}

function padEpisodeNumber(num, width = 3) {
  return String(Math.max(1, Number(num) || 1)).padStart(width, '0');
}

function isHttpUrl(raw) {
  if (!raw || typeof raw !== 'string') return false;
  try {
    const u = new URL(raw);
    return (u.protocol === 'http:' || u.protocol === 'https:') && Boolean(u.hostname);
  } catch {
    return false;
  }
}

function isHongguoHostname(hostname) {
  const host = String(hostname || '').toLowerCase();
  return host === 'hongguoduanju.com' || host.endsWith('.hongguoduanju.com');
}

/**
 * Converts Hongguo HEIC novel-pic URLs into standard non-expiring JPEG URLs.
 */
function normalizeCoverUrl(rawUrl) {
  const s = String(rawUrl || '').trim();
  if (!s || !isHttpUrl(s)) return '';
  const heicMatch = /\/novel-pic\/([a-f0-9]+)(?:~|\.)/i.exec(s);
  if (heicMatch && s.toLowerCase().includes('.heic')) {
    return `https://p6-novel.byteimg.com/novel-pic/${heicMatch[1]}~tplv-shrink:640:0.image`;
  }
  return s;
}

function runExec(bin, args, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, { windowsHide: true });
    let stderr = '';
    const timer = setTimeout(() => {
      try {
        child.kill('SIGTERM');
      } catch {
        // Ignore kill error
      }
      reject(new Error(`Process timeout: ${bin}`));
    }, timeoutMs);

    child.stderr.on('data', (d) => {
      stderr = (stderr + d.toString('utf8')).slice(-2000);
    });
    child.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) resolve();
      else reject(new Error(stderr.trim() || `${bin} exited with code ${code}`));
    });
  });
}

/**
 * Validates user input (URL, numeric series ID, or drama title).
 * Strictly rejects URLs from any domain other than hongguoduanju.com.
 */
function parseHongguoInput(input) {
  const trimmed = String(input || '').trim();
  if (!trimmed) {
    throw createAppError(
      'EMPTY_INPUT',
      'សូមបញ្ចូលតំណភ្ជាប់ពី https://hongguoduanju.com/ ឬលេខសម្គាល់រឿង!'
    );
  }

  if (URL_LIKE_RE.test(trimmed)) {
    const withScheme = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
    let parsedUrl;
    try {
      parsedUrl = new URL(withScheme);
    } catch {
      throw createAppError(
        'INVALID_SOURCE',
        'អនុញ្ញាតតែតំណភ្ជាប់ពីគេហទំព័រ https://hongguoduanju.com/ ប៉ុណ្ណោះ! (Only hongguoduanju.com links are allowed)'
      );
    }

    if (!isHongguoHostname(parsedUrl.hostname)) {
      throw createAppError(
        'INVALID_SOURCE',
        'អនុញ្ញាតតែតំណភ្ជាប់ពីគេហទំព័រ https://hongguoduanju.com/ ប៉ុណ្ណោះ! (Only hongguoduanju.com links are allowed)'
      );
    }

    const sp = parsedUrl.searchParams;
    let seriesId = sp.get('series_id') || sp.get('book_id') || sp.get('id') || '';
    let episodeId = sp.get('vid') || sp.get('episode_id') || sp.get('video_id') || '';
    const segments = parsedUrl.pathname.split('/').filter(Boolean);

    if (segments[0] === 'player') {
      if (!seriesId && NUMERIC_ID_RE.test(segments[1] || '')) seriesId = segments[1];
      if (!episodeId && NUMERIC_ID_RE.test(segments[2] || '')) episodeId = segments[2];
    } else if (segments[0] === 'detail') {
      if (!seriesId && NUMERIC_ID_RE.test(segments[1] || '')) seriesId = segments[1];
    }

    if (!seriesId) {
      const numericSegments = segments.filter((seg) => NUMERIC_ID_RE.test(seg));
      if (numericSegments.length >= 1) seriesId = numericSegments[0];
      if (!episodeId && numericSegments.length >= 2) episodeId = numericSegments[1];
    }

    if (!NUMERIC_ID_RE.test(seriesId)) {
      throw createAppError(
        'MISSING_SERIES_ID',
        'តំណភ្ជាប់ hongguoduanju.com នេះមិនមានលេខសម្គាល់រឿងទេ។ សូមប្រើតំណ /detail?series_id=... ឬ /player/...'
      );
    }

    return {
      type: 'series',
      seriesId,
      episodeId: NUMERIC_ID_RE.test(episodeId) ? episodeId : null,
      sourceUrl: `${HONGGUO_BASE}/detail?series_id=${seriesId}`,
    };
  }

  if (NUMERIC_ID_RE.test(trimmed)) {
    return {
      type: 'series',
      seriesId: trimmed,
      episodeId: null,
      sourceUrl: `${HONGGUO_BASE}/detail?series_id=${trimmed}`,
    };
  }

  return {
    type: 'search',
    query: trimmed,
  };
}

/**
 * Quotes bare 15-32 digit integers in a JSON string outside string literals
 * so 64-bit series_id and vid values do not lose precision in JSON.parse().
 */
function quoteLargeIntegers(jsonStr) {
  let out = '';
  let i = 0;
  const len = jsonStr.length;
  let inString = false;
  let escaped = false;

  while (i < len) {
    const ch = jsonStr[i];
    if (inString) {
      out += ch;
      if (escaped) {
        escaped = false;
      } else if (ch === '\\') {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }
      i += 1;
      continue;
    }

    if (ch === '"') {
      inString = true;
      out += ch;
      i += 1;
      continue;
    }

    if (ch >= '0' && ch <= '9') {
      let j = i;
      while (j < len && jsonStr[j] >= '0' && jsonStr[j] <= '9') {
        j += 1;
      }
      const token = jsonStr.slice(i, j);
      const nextCh = jsonStr[j] || '';
      const isPlainInt = nextCh !== '.' && nextCh !== 'e' && nextCh !== 'E';

      let prevIdx = out.length - 1;
      while (prevIdx >= 0 && /\s/.test(out[prevIdx])) prevIdx -= 1;
      const prevCh = prevIdx >= 0 ? out[prevIdx] : '';
      const afterValueDelimiter = prevCh === ':' || prevCh === '[' || prevCh === ',';

      let nextIdx = j;
      while (nextIdx < len && /\s/.test(jsonStr[nextIdx])) nextIdx += 1;
      const afterCh = nextIdx < len ? jsonStr[nextIdx] : '';
      const beforeValueDelimiter = afterCh === ',' || afterCh === ']' || afterCh === '}' || afterCh === '';

      if (isPlainInt && afterValueDelimiter && beforeValueDelimiter && token.length >= 15 && token.length <= 32) {
        out += `"${token}"`;
      } else {
        out += token;
      }
      i = j;
      continue;
    }

    out += ch;
    i += 1;
  }

  return out;
}

/**
 * Extracts and parses window._ROUTER_DATA = {...} from Hongguo HTML without
 * corrupting 64-bit integer IDs.
 */
function parseRouterDataFromHTML(html) {
  if (!html || typeof html !== 'string') return null;
  const match = /_ROUTER_DATA\s*=\s*/.exec(html);
  if (!match) return null;

  const startSearch = match.index + match[0].length;
  const startBrace = html.indexOf('{', startSearch);
  if (startBrace === -1) return null;

  let depth = 0;
  let inString = false;
  let escaped = false;
  let endBrace = -1;

  for (let i = startBrace; i < html.length; i += 1) {
    const ch = html[i];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === '\\') {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }

    if (ch === '"') {
      inString = true;
    } else if (ch === '{') {
      depth += 1;
    } else if (ch === '}') {
      depth -= 1;
      if (depth === 0) {
        endBrace = i;
        break;
      }
    }
  }

  if (endBrace === -1) return null;
  const rawJson = html.slice(startBrace, endBrace + 1);
  try {
    return JSON.parse(quoteLargeIntegers(rawJson));
  } catch {
    return null;
  }
}

function loaderPage(routerData, ...prefixes) {
  const loader = routerData && typeof routerData.loaderData === 'object' ? routerData.loaderData : null;
  if (!loader) return null;

  for (const name of prefixes) {
    const candidate = loader[name];
    if (candidate && typeof candidate === 'object' && Object.keys(candidate).length > 0) {
      return candidate;
    }
  }

  const sortedKeys = Object.keys(loader).sort();
  for (const key of sortedKeys) {
    for (const prefix of prefixes) {
      if (key.startsWith(prefix)) {
        const candidate = loader[key];
        if (candidate && typeof candidate === 'object' && Object.keys(candidate).length > 0) {
          return candidate;
        }
      }
    }
  }

  return null;
}

function extractTags(obj) {
  const tags = [];
  const add = (val) => {
    const s = String(val || '').trim();
    if (s && !tags.includes(s)) tags.push(s);
  };

  if (!obj || typeof obj !== 'object') return tags;
  if (typeof obj.tags === 'string') {
    for (const part of obj.tags.split(/[,，]/)) add(part);
  } else if (Array.isArray(obj.tags)) {
    for (const item of obj.tags) add(item);
  }
  if (Array.isArray(obj.category_list)) {
    for (const c of obj.category_list) add(c && c.name);
  }
  if (typeof obj.category_schema === 'string') {
    try {
      const parsed = JSON.parse(obj.category_schema);
      if (Array.isArray(parsed)) {
        for (const c of parsed) add(c && c.name);
      }
    } catch {
      // Ignore malformed category_schema
    }
  }
  return tags;
}

function decodeBase64UrlCandidate(value) {
  const s = String(value || '').trim();
  if (!s || s.length > 8192) return null;
  if (isHttpUrl(s)) return s;
  try {
    const decoded = Buffer.from(s, 'base64').toString('utf8').trim();
    return isHttpUrl(decoded) ? decoded : null;
  } catch {
    return null;
  }
}

function collectMediaAddresses(info) {
  if (!info || typeof info !== 'object') return [];
  const out = [];
  const seen = new Set();

  const pushVal = (v) => {
    if (typeof v === 'string') {
      const url = decodeBase64UrlCandidate(v);
      if (url && !seen.has(url)) {
        seen.add(url);
        out.push(url);
      }
    } else if (Array.isArray(v)) {
      for (const item of v) pushVal(item);
    }
  };

  for (const key of ['main_url', 'backup_url', 'backup_url_1', 'backup_url_2', 'backup_urls', 'url_list']) {
    pushVal(info[key]);
  }
  return out;
}

function pickStreamForQuality(streams, quality = 'best') {
  if (!Array.isArray(streams) || streams.length === 0) return null;

  const parseRes = (s) => {
    const defMatch = String(s.definition || '').match(/(\d+)/);
    if (defMatch) return Number(defMatch[1]);
    if (s.width && s.height) return Math.min(s.width, s.height);
    return 0;
  };

  const scoreStream = (s) => {
    const res = parseRes(s);
    const bitrate = Number(s.bitrate) || 0;
    const size = Number(s.size) || 0;
    return res * 1e9 + bitrate * 10 + size;
  };

  const sorted = [...streams]
    .filter((s) => isHttpUrl(s.url) || isHttpUrl(s.backup_url))
    .sort((a, b) => scoreStream(b) - scoreStream(a));

  if (sorted.length === 0) return null;

  const q = String(quality || 'best').toLowerCase().trim();
  if (!q || q === 'best') return sorted[0];
  if (q === 'worst') return sorted[sorted.length - 1];

  const targetMatch = q.match(/(\d+)/);
  if (!targetMatch) return sorted[0];
  const target = Number(targetMatch[1]);

  const exact = sorted.find((s) => parseRes(s) === target);
  if (exact) return exact;

  const lowerOrEqual = sorted.find((s) => parseRes(s) > 0 && parseRes(s) <= target);
  if (lowerOrEqual) return lowerOrEqual;

  return sorted[sorted.length - 1];
}

function parseFfmpegTimeSeconds(line) {
  const match = /time=(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(line);
  if (!match) return null;
  return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]);
}

function parseFfmpegSizeBytes(line) {
  const match = /(?:L?size)=\s*(\d+)\s*(KiB|kB|MiB|MB|B)/i.exec(line);
  if (!match) return null;
  const val = Number(match[1]);
  const unit = match[2].toLowerCase();
  if (unit === 'kib' || unit === 'kb') return val * 1024;
  if (unit === 'mib' || unit === 'mb') return val * 1024 * 1024;
  return val;
}

class HongguoService {
  constructor(options = {}) {
    this.profilePath = options.profilePath || null;
    this._clientPromise = null;
    this._seriesCoverCache = new Map();
    this._folderSetupPromises = new Map();
  }

  getCategories() {
    return WEB_CATEGORIES.map((c) => ({ ...c }));
  }

  getNewUpdateTypes() {
    return NEW_UPDATE_TYPES.map((t) => ({ ...t }));
  }

  /**
   * Fetches newly released or newly updated dramas/movies from Hongguo.
   */
  async fetchNewUpdates(type = 'new-calendar', cursor = '') {
    const client = await this.getClient();
    const cleanCursor = String(cursor || '').trim();

    if (type === 'new-calendar') {
      try {
        const res = await client.newReleases(cleanCursor ? { cursor: cleanCursor } : {});
        const onlineItems = (res.items || []).filter((item) => item.online !== false);
        const mapped = onlineItems.map((item) => ({
          id: String(item.series_id),
          title: String(item.title || item.series_id).trim(),
          description: String(item.description || '').trim(),
          cover: normalizeCoverUrl(item.cover_url || ''),
          episodeCount: Number(item.episode_count) || 0,
          isNew: true,
          heat: String(item.heat || '').trim(),
          publishAt: item.publish_at ? String(item.publish_at).slice(0, 10) : 'ទើបចេញថ្មី',
          tags: Array.isArray(item.categories) ? item.categories : [],
          url: `${HONGGUO_BASE}/detail?series_id=${item.series_id}`,
        }));

        if (mapped.length > 0) {
          return {
            type,
            items: mapped,
            hasMore: Boolean(res.has_more && res.cursor),
            nextCursor: res.cursor || '',
          };
        }
      } catch {
        // Fallback to latest online_time filter below
      }
    }

    const genreMap = {
      'new-calendar': 'short_play',
      'latest-drama': 'short_play',
      'latest-comic': 'comic_series',
      'latest-ai': 'ai_series',
    };
    const genre = genreMap[type] || 'short_play';

    const filterRes = await client.shortFilter({
      selections: {
        genre: [genre],
        sort: ['online_time'],
      },
      cursor: cleanCursor || undefined,
    });

    return {
      type,
      items: (filterRes.items || []).map((s) => ({
        id: String(s.id),
        title: String(s.title || s.id).trim(),
        description: String(s.description || '').trim(),
        cover: normalizeCoverUrl(s.cover_url || ''),
        episodeCount: Number(s.episode_count) || 0,
        isNew: true,
        heat: '',
        publishAt: 'ទើបអាប់ដេតថ្មី',
        tags: s.category ? [s.category] : [],
        url: `${HONGGUO_BASE}/detail?series_id=${s.id}`,
      })),
      hasMore: Boolean(filterRes.has_more && filterRes.cursor),
      nextCursor: filterRes.cursor || '',
    };
  }

  async getClient() {
    if (!this._clientPromise) {
      this._clientPromise = (async () => {
        ensureOpenhongguoWasmShim();
        const sdk = await import('openhongguo');
        const clientOptions = {
          retryAttempts: 3,
          deviceResets: 2,
          timeoutMs: 25000,
        };
        if (this.profilePath) {
          await fsp.mkdir(path.dirname(this.profilePath), { recursive: true });
          clientOptions.profile = this.profilePath;
        }
        return sdk.createClient(clientOptions);
      })().catch((err) => {
        this._clientPromise = null;
        throw err;
      });
    }
    return this._clientPromise;
  }

  async fetchHtml(url) {
    const parsed = new URL(url);
    if (!isHongguoHostname(parsed.hostname)) {
      throw createAppError(
        'INVALID_SOURCE',
        'អនុញ្ញាតតែតំណភ្ជាប់ពីគេហទំព័រ https://hongguoduanju.com/ ប៉ុណ្ណោះ!'
      );
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);
    try {
      const res = await fetch(url, {
        method: 'GET',
        headers: DEFAULT_HEADERS,
        signal: controller.signal,
      });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status} from ${url}`);
      }
      return await res.text();
    } finally {
      clearTimeout(timer);
    }
  }

  async fetchWebCategory(categoryId = 'real-drama', page = 1) {
    const validIds = new Set(WEB_CATEGORIES.map((c) => c.id));
    const route = validIds.has(categoryId) ? categoryId : 'real-drama';
    const pageNum = Math.max(1, Number(page) || 1);

    try {
      const html = await this.fetchHtml(`${HONGGUO_BASE}/category/${route}?page=${pageNum}`);
      const routerData = parseRouterDataFromHTML(html);
      const data = loaderPage(routerData, 'category_page', 'category_');
      if (data && data.isSuccess !== false && Array.isArray(data.recommendList)) {
        const items = [];
        const seen = new Set();
        for (const entry of data.recommendList) {
          const vd = entry && typeof entry.video_data === 'object' ? entry.video_data : entry;
          if (!vd || typeof vd !== 'object') continue;
          const id = String(vd.series_id_str || vd.series_id || entry.series_id_str || entry.series_id || '').trim();
          if (!NUMERIC_ID_RE.test(id) || seen.has(id)) continue;
          seen.add(id);
          const epCount = Number(vd.episode_cnt || entry.episode_cnt || 0) || 0;
          items.push({
            id,
            title: String(vd.series_title || vd.series_name || vd.title || entry.title || id).trim(),
            cover: normalizeCoverUrl(vd.series_cover || vd.cover || entry.cover || ''),
            episodeCount: epCount,
            subtitle: String(vd.episode_right_text || entry.episode_right_text || (epCount ? `សរុប ${epCount} ភាគ` : '')),
            tags: extractTags(vd),
            url: `${HONGGUO_BASE}/detail?series_id=${id}`,
          });
        }

        if (items.length > 0) {
          const totalPages = Number(data.pagination && data.pagination.totalPages) || 0;
          return {
            categoryId: route,
            page: pageNum,
            hasMore: totalPages > 0 ? pageNum < totalPages : items.length >= 24,
            items,
          };
        }
      }
    } catch {
      // Fallback to anonymous SDK discovery below
    }

    const client = await this.getClient();
    const genreMap = {
      'real-drama': 'short_play',
      'comic-drama': 'comic_series',
      'ai-drama': 'ai_series',
      comic: 'comic_series',
    };
    try {
      const res = await client.shortFilter({
        selections: { genre: [genreMap[route] || 'short_play'], sort: ['hot_score'] },
      });
      return {
        categoryId: route,
        page: 1,
        hasMore: Boolean(res.has_more),
        items: (res.items || []).map((s) => ({
          id: s.id,
          title: s.title,
          cover: normalizeCoverUrl(s.cover_url || ''),
          episodeCount: s.episode_count || 0,
          subtitle: s.episode_count ? `សរុប ${s.episode_count} ភាគ` : '',
          tags: s.category ? [s.category] : [],
          url: `${HONGGUO_BASE}/detail?series_id=${s.id}`,
        })),
      };
    } catch {
      const disc = await client.discover();
      return {
        categoryId: route,
        page: 1,
        hasMore: Boolean(disc.has_more),
        items: (disc.items || []).map((s) => ({
          id: s.id,
          title: s.title,
          cover: normalizeCoverUrl(s.cover_url || ''),
          episodeCount: s.episode_count || 0,
          subtitle: s.episode_count ? `សរុប ${s.episode_count} ភាគ` : '',
          tags: s.category ? [s.category] : [],
          url: `${HONGGUO_BASE}/detail?series_id=${s.id}`,
        })),
      };
    }
  }

  async searchSeries(query) {
    const trimmed = String(query || '').trim();
    if (!trimmed) return [];

    try {
      const client = await this.getClient();
      const page = await client.search(trimmed, { pageSize: 20 });
      if (page && Array.isArray(page.items) && page.items.length > 0) {
        return page.items.map((s) => ({
          id: s.id,
          title: s.title,
          description: s.description || '',
          cover: normalizeCoverUrl(s.cover_url || ''),
          episodeCount: s.episode_count || 0,
          tags: s.category ? [s.category] : [],
          url: `${HONGGUO_BASE}/detail?series_id=${s.id}`,
        }));
      }
    } catch {
      // Fallback to web category scan below
    }

    const needle = trimmed.toLowerCase();
    const matches = [];
    const seen = new Set();
    for (const cat of WEB_CATEGORIES) {
      for (let p = 1; p <= 2; p += 1) {
        try {
          const catPage = await this.fetchWebCategory(cat.id, p);
          for (const item of catPage.items) {
            if (seen.has(item.id)) continue;
            seen.add(item.id);
            if (item.title.toLowerCase().includes(needle)) {
              matches.push(item);
            }
          }
          if (!catPage.hasMore) break;
        } catch {
          break;
        }
      }
    }
    return matches;
  }

  async _fetchWebSeriesDetail(seriesId) {
    try {
      const html = await this.fetchHtml(`${HONGGUO_BASE}/detail?series_id=${seriesId}`);
      const routerData = parseRouterDataFromHTML(html);
      const page = loaderPage(routerData, 'detail_page', 'detail_');
      const detail = page && page.seriesDetail ? page.seriesDetail : null;
      if (!detail || typeof detail !== 'object') return null;

      const vidList = Array.isArray(detail.vid_list) ? detail.vid_list : [];
      const episodes = vidList
        .map((v, idx) => {
          const id = String(v || '').trim();
          if (!NUMERIC_ID_RE.test(id)) return null;
          return {
            id,
            seriesId,
            number: idx + 1,
            title: `ភាគ ${idx + 1}`,
            cover: '',
            playable: true,
            pageUrl: `${HONGGUO_BASE}/player/${seriesId}/${id}`,
          };
        })
        .filter(Boolean);

      return {
        id: seriesId,
        title: String(detail.series_name || detail.series_title || detail.name || seriesId).trim(),
        cover: normalizeCoverUrl(detail.cover || detail.series_cover || ''),
        description: String(detail.intro || detail.series_intro || '').trim(),
        tags: extractTags(detail),
        episodes,
      };
    } catch {
      return null;
    }
  }

  async _fetchSdkSeriesDetail(seriesId) {
    const client = await this.getClient();
    const [seriesInfo, allEpisodes] = await Promise.all([
      client.getSeries(seriesId).catch(() => null),
      (async () => {
        const items = [];
        let cursor = '';
        for (let i = 0; i < 20; i += 1) {
          const page = await client.listEpisodes(seriesId, { cursor, pageSize: 100 });
          if (Array.isArray(page.items)) items.push(...page.items);
          if (!page.has_more || !page.cursor) break;
          cursor = page.cursor;
        }
        return items;
      })(),
    ]);

    return {
      seriesInfo,
      episodes: (allEpisodes || []).map((ep, idx) => ({
        id: String(ep.id),
        seriesId: String(ep.series_id || seriesId),
        number: Number(ep.number) || idx + 1,
        title: ep.title || `ភាគ ${Number(ep.number) || idx + 1}`,
        cover: normalizeCoverUrl(ep.cover_url || ''),
        playable: ep.playable !== false,
        pageUrl: `${HONGGUO_BASE}/player/${seriesId}/${ep.id}`,
      })),
    };
  }

  async fetchSeriesDetails(input) {
    const parsed = parseHongguoInput(input);
    let seriesId = parsed.seriesId;
    const targetEpisodeId = parsed.episodeId || null;
    let searchMatches = [];

    if (parsed.type === 'search') {
      searchMatches = await this.searchSeries(parsed.query);
      if (searchMatches.length === 0) {
        throw createAppError(
          'NOT_FOUND',
          `រកមិនឃើញរឿង "${parsed.query}" នៅលើ hongguoduanju.com ទេ។`
        );
      }
      const exact = searchMatches.find((m) => m.title === parsed.query);
      seriesId = (exact || searchMatches[0]).id;
    }

    const [webResult, sdkResult] = await Promise.all([
      this._fetchWebSeriesDetail(seriesId),
      this._fetchSdkSeriesDetail(seriesId).catch((err) => ({ error: err, seriesInfo: null, episodes: [] })),
    ]);

    const sdkInfo = sdkResult.seriesInfo;
    const sdkEpisodes = sdkResult.episodes || [];
    const webEpisodes = (webResult && webResult.episodes) || [];

    if (sdkEpisodes.length === 0 && webEpisodes.length === 0) {
      const reason = sdkResult.error ? sdkResult.error.message : 'មិនមានទិន្នន័យភាគរឿង';
      throw createAppError(
        'NO_EPISODES',
        `មិនអាចទាញយកបញ្ជីភាគពី hongguoduanju.com បានទេ៖ ${reason}`,
        sdkResult.error
      );
    }

    const mergedMap = new Map();
    for (const ep of webEpisodes) {
      mergedMap.set(ep.id, ep);
    }
    for (const ep of sdkEpisodes) {
      const existing = mergedMap.get(ep.id);
      mergedMap.set(ep.id, existing ? { ...existing, ...ep } : ep);
    }

    const episodes = Array.from(mergedMap.values()).sort((a, b) => a.number - b.number);
    const title =
      (sdkInfo && sdkInfo.title) ||
      (webResult && webResult.title) ||
      seriesId;
    const matchedSearchCover =
      (searchMatches.find((m) => String(m.id) === String(seriesId)) || searchMatches[0] || {}).cover || '';
    const firstEpCover = (episodes.find((ep) => ep.cover) || {}).cover || '';
    const cover =
      (webResult && normalizeCoverUrl(webResult.cover)) ||
      (sdkInfo && normalizeCoverUrl(sdkInfo.cover_url)) ||
      normalizeCoverUrl(matchedSearchCover) ||
      normalizeCoverUrl(firstEpCover) ||
      '';
    const description =
      (sdkInfo && sdkInfo.description) ||
      (webResult && webResult.description) ||
      '';
    const tags =
      (webResult && webResult.tags && webResult.tags.length > 0 ? webResult.tags : []) ||
      (sdkInfo && sdkInfo.category ? [sdkInfo.category] : []);

    const episodeCovers = new Map();
    for (const ep of episodes) {
      if (ep.cover) episodeCovers.set(String(ep.id), ep.cover);
    }
    this._seriesCoverCache.set(String(seriesId), {
      seriesCover: cover,
      episodeCovers,
    });

    return {
      id: seriesId,
      title,
      cover,
      description,
      episodeCount: Math.max(episodes.length, (sdkInfo && sdkInfo.episode_count) || 0),
      tags,
      sourceUrl: `${HONGGUO_BASE}/detail?series_id=${seriesId}`,
      targetEpisodeId,
      episodes,
      searchMatches,
    };
  }

  async resolveEpisodePlayback(seriesId, episodeId, quality = 'best') {
    let sdkError = null;
    try {
      const client = await this.getClient();
      const res = await client.resolvePlayback(String(episodeId));
      const pb = res && res.playback;
      if (pb && Array.isArray(pb.streams) && pb.streams.length > 0) {
        const chosen = pickStreamForQuality(pb.streams, quality);
        if (chosen) {
          if (pb.protected && !(res.contentKey && res.contentKey.key)) {
            throw createAppError(
              'KEY_UNAVAILABLE',
              res.contentKeyError?.message || 'មិនអាចគណនាកូនសោបម្លែងវីដេអូសម្រាប់ភាគនេះបានទេ'
            );
          }
          return {
            source: 'sdk',
            url: chosen.url || chosen.backup_url,
            backupUrl: chosen.backup_url && chosen.backup_url !== chosen.url ? chosen.backup_url : null,
            audioUrl: pb.audio_url || null,
            protected: Boolean(pb.protected || chosen.protected),
            decryptionKey: res.contentKey ? res.contentKey.key : null,
            hls: Boolean(chosen.hls),
            definition: chosen.definition || 'auto',
            expectedSize: Number(chosen.size) || 0,
            durationSeconds: Number(pb.duration_seconds) || 0,
          };
        }
      }
    } catch (err) {
      sdkError = err;
    }

    // Fallback: public web player page on https://hongguoduanju.com/player/<seriesId>/<episodeId>
    try {
      const html = await this.fetchHtml(`${HONGGUO_BASE}/player/${seriesId}/${episodeId}`);
      const routerData = parseRouterDataFromHTML(html);
      const page = loaderPage(routerData, 'player_page', 'player_');
      if (
        page &&
        String(page.vid || '') === String(episodeId) &&
        String(page.series_id || '') === String(seriesId)
      ) {
        const addrs = collectMediaAddresses(page.video_player_info);
        if (addrs.length > 0) {
          const primary = addrs[0];
          const isHls = primary.split('?')[0].toLowerCase().endsWith('.m3u8');
          return {
            source: 'web',
            url: primary,
            backupUrl: addrs[1] || null,
            audioUrl: null,
            protected: false,
            decryptionKey: null,
            hls: isHls,
            definition: 'web',
            expectedSize: 0,
            durationSeconds: 0,
          };
        }
      }
    } catch {
      // Ignore web fallback error if SDK error was more informative
    }

    throw createAppError(
      'PLAYBACK_UNAVAILABLE',
      `មិនអាចទាញយកតំណភ្ជាប់វីដេអូសម្រាប់ភាគនេះពី hongguoduanju.com បានទេ${sdkError ? ` (${sdkError.message})` : ''}`,
      sdkError
    );
  }

  async _downloadHttpFile(url, destPath, expectedSize, signal, onProgress, includeReferer = false) {
    await fsp.rm(destPath, { force: true }).catch(() => {});

    const headers = {
      'User-Agent': DEFAULT_HEADERS['User-Agent'],
    };
    if (includeReferer) {
      headers.Referer = `${HONGGUO_BASE}/`;
    }

    const requestWithRedirects = (targetUrl, redirectCount = 0) =>
      new Promise((resolve, reject) => {
        if (signal && signal.aborted) {
          return reject(createAppError('ABORTED', 'ការទាញយកត្រូវបានបោះបង់'));
        }
        if (redirectCount > 6) {
          return reject(new Error('Too many HTTP redirects'));
        }

        const parsed = new URL(targetUrl);
        const mod = parsed.protocol === 'http:' ? http : https;
        const req = mod.get(
          targetUrl,
          { headers },
          (res) => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
              res.resume();
              const nextUrl = new URL(res.headers.location, targetUrl).toString();
              resolve(requestWithRedirects(nextUrl, redirectCount + 1));
              return;
            }

            if (res.statusCode !== 200 && res.statusCode !== 206) {
              res.resume();
              reject(new Error(`HTTP ${res.statusCode}`));
              return;
            }

            const totalBytes = Number(res.headers['content-length']) || expectedSize || 0;
            let downloadedBytes = 0;
            let lastEmit = 0;

            const outStream = fs.createWriteStream(destPath);
            const cleanup = () => {
              res.destroy();
              outStream.destroy();
              req.destroy();
            };

            const onAbort = () => {
              cleanup();
              reject(createAppError('ABORTED', 'ការទាញយកត្រូវបានបោះបង់'));
            };

            if (signal) {
              signal.addEventListener('abort', onAbort, { once: true });
            }

            res.on('data', (chunk) => {
              downloadedBytes += chunk.length;
              const now = Date.now();
              if (now - lastEmit >= 150) {
                lastEmit = now;
                const percent = totalBytes > 0 ? Math.min(99, Math.round((downloadedBytes / totalBytes) * 100)) : 0;
                if (onProgress) {
                  onProgress({
                    status: 'downloading',
                    percent,
                    downloadedBytes,
                    totalBytes,
                  });
                }
              }
            });

            outStream.on('finish', () => {
              if (signal) signal.removeEventListener('abort', onAbort);
              resolve(downloadedBytes);
            });

            outStream.on('error', (err) => {
              if (signal) signal.removeEventListener('abort', onAbort);
              cleanup();
              reject(err);
            });

            res.on('error', (err) => {
              if (signal) signal.removeEventListener('abort', onAbort);
              cleanup();
              reject(err);
            });

            res.pipe(outStream);
          }
        );

        req.setTimeout(30000, () => {
          req.destroy(new Error('Request timeout'));
        });

        req.on('error', (err) => {
          reject(err);
        });
      });

    try {
      return await requestWithRedirects(url);
    } catch (err) {
      await fsp.rm(destPath, { force: true }).catch(() => {});
      throw err;
    }
  }

  async _downloadWithFfmpeg(playback, streamUrl, destPath, signal, onProgress) {
    const ffmpegBin = resolveFfmpegPath();
    if (!ffmpegBin || !fs.existsSync(ffmpegBin)) {
      throw createAppError('FFMPEG_MISSING', 'រកមិនឃើញកម្មវិធី ffmpeg សម្រាប់បំប្លែងវីដេអូទេ');
    }

    await fsp.rm(destPath, { force: true }).catch(() => {});

    const includeReferer = playback.source === 'web';
    const headerValue = `Referer: ${HONGGUO_BASE}/\r\nUser-Agent: ${DEFAULT_HEADERS['User-Agent']}\r\n`;
    const args = ['-hide_banner', '-loglevel', 'info', '-nostdin', '-y'];

    const addInput = (inputUrl) => {
      if (includeReferer) {
        args.push('-headers', headerValue);
      }
      if (playback.protected && playback.decryptionKey) {
        args.push('-decryption_key', playback.decryptionKey);
      }
      args.push('-i', inputUrl);
    };

    addInput(streamUrl);
    if (playback.audioUrl) {
      addInput(playback.audioUrl);
      args.push('-map', '0:v:0', '-map', '1:a:0');
    } else {
      args.push('-map', '0');
    }

    args.push('-c', 'copy');
    if (playback.hls) {
      args.push('-bsf:a', 'aac_adtstoasc');
    }
    args.push('-movflags', '+faststart', '-f', 'mp4', destPath);

    return new Promise((resolve, reject) => {
      if (signal && signal.aborted) {
        return reject(createAppError('ABORTED', 'ការទាញយកត្រូវបានបោះបង់'));
      }

      const child = spawn(ffmpegBin, args, { windowsHide: true });
      let stderrTail = '';
      let durationSec = playback.durationSeconds || 0;
      let lastBytes = 0;

      const onAbort = () => {
        try {
          child.kill('SIGTERM');
        } catch {
          // Ignore kill error
        }
      };
      if (signal) {
        signal.addEventListener('abort', onAbort, { once: true });
      }

      child.stderr.on('data', (buf) => {
        const text = buf.toString('utf8');
        stderrTail = (stderrTail + text).slice(-4000);

        if (!durationSec) {
          const durMatch = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(text);
          if (durMatch) {
            durationSec = Number(durMatch[1]) * 3600 + Number(durMatch[2]) * 60 + Number(durMatch[3]);
          }
        }

        const curTime = parseFfmpegTimeSeconds(text);
        const curSize = parseFfmpegSizeBytes(text);
        if (curSize !== null) lastBytes = curSize;

        if (onProgress && (curTime !== null || curSize !== null)) {
          const percent =
            durationSec > 0 && curTime !== null
              ? Math.min(99, Math.round((curTime / durationSec) * 100))
              : 0;
          onProgress({
            status: 'downloading',
            percent,
            downloadedBytes: lastBytes,
            totalBytes: playback.expectedSize || 0,
          });
        }
      });

      child.on('error', async (err) => {
        if (signal) signal.removeEventListener('abort', onAbort);
        await fsp.rm(destPath, { force: true }).catch(() => {});
        reject(err);
      });

      child.on('close', async (code) => {
        if (signal) signal.removeEventListener('abort', onAbort);
        if (signal && signal.aborted) {
          await fsp.rm(destPath, { force: true }).catch(() => {});
          return reject(createAppError('ABORTED', 'ការទាញយកត្រូវបានបោះបង់'));
        }
        if (code !== 0) {
          await fsp.rm(destPath, { force: true }).catch(() => {});
          const firstLine = stderrTail.trim().split(/\r?\n/).pop() || `ffmpeg exited with code ${code}`;
          return reject(new Error(firstLine));
        }
        try {
          const st = await fsp.stat(destPath);
          resolve(st.size);
        } catch (err) {
          reject(err);
        }
      });
    });
  }

  async _resolveCovers(seriesId, episodeId, seriesCover, episodeCover) {
    let resolvedSeriesCover = normalizeCoverUrl(seriesCover);
    let resolvedEpisodeCover = normalizeCoverUrl(episodeCover);

    const key = String(seriesId);
    let cached = this._seriesCoverCache.get(key);
    if (!cached && (!resolvedSeriesCover || !resolvedEpisodeCover)) {
      await this.fetchSeriesDetails(key).catch(() => null);
      cached = this._seriesCoverCache.get(key);
    }

    if (cached) {
      if (!resolvedSeriesCover && cached.seriesCover) {
        resolvedSeriesCover = cached.seriesCover;
      }
      if (!resolvedEpisodeCover && cached.episodeCovers) {
        resolvedEpisodeCover = cached.episodeCovers.get(String(episodeId)) || '';
      }
    }

    return {
      seriesCover: resolvedSeriesCover,
      episodeCover: resolvedEpisodeCover || resolvedSeriesCover,
    };
  }

  async _downloadImageAsJpg(imageUrl, destJpgPath) {
    const cleanUrl = normalizeCoverUrl(imageUrl);
    if (!cleanUrl) return null;

    const tmpPath = `${destJpgPath}.${process.pid}.${Date.now()}.tmp`;
    try {
      await this._downloadHttpFile(cleanUrl, tmpPath, 0, null, null, false);
      const buf = await fsp.readFile(tmpPath);
      if (buf.length < 64) {
        await fsp.rm(tmpPath, { force: true }).catch(() => {});
        return null;
      }

      const isJpeg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
      if (isJpeg) {
        await fsp.rm(destJpgPath, { force: true }).catch(() => {});
        await fsp.rename(tmpPath, destJpgPath);
        return destJpgPath;
      }

      const ffmpegBin = resolveFfmpegPath();
      if (ffmpegBin && fs.existsSync(ffmpegBin)) {
        await runExec(ffmpegBin, [
          '-hide_banner',
          '-loglevel',
          'error',
          '-nostdin',
          '-y',
          '-i',
          tmpPath,
          '-frames:v',
          '1',
          '-q:v',
          '2',
          destJpgPath,
        ]);
        await fsp.rm(tmpPath, { force: true }).catch(() => {});
        if (fs.existsSync(destJpgPath)) return destJpgPath;
      }
    } catch {
      await fsp.rm(tmpPath, { force: true }).catch(() => {});
    }
    return null;
  }

  async _extractFrameAsJpg(videoPath, destJpgPath) {
    if (!videoPath || !fs.existsSync(videoPath)) return null;
    const ffmpegBin = resolveFfmpegPath();
    if (!ffmpegBin || !fs.existsSync(ffmpegBin)) return null;

    try {
      await runExec(ffmpegBin, [
        '-hide_banner',
        '-loglevel',
        'error',
        '-nostdin',
        '-y',
        '-ss',
        '00:00:01',
        '-i',
        videoPath,
        '-frames:v',
        '1',
        '-q:v',
        '2',
        destJpgPath,
      ]);
      return fs.existsSync(destJpgPath) ? destJpgPath : null;
    } catch {
      return null;
    }
  }

  /**
   * Downloads the series thumbnail (cover.jpg, <safeTitle>_thumbnail.jpg, folder.jpg)
   * and configures the folder to use the drama thumbnail as its Windows folder icon
   * instead of the default folder icon (folder.ico + desktop.ini + Windows attributes).
   */
  async ensureSeriesFolderThumbnail(seriesDir, safeTitle, coverUrl, fallbackVideoPath = null) {
    const dirKey = path.resolve(seriesDir);
    if (this._folderSetupPromises.has(dirKey)) {
      return this._folderSetupPromises.get(dirKey);
    }

    const promise = (async () => {
      const coverJpgPath = path.join(seriesDir, 'cover.jpg');
      const namedThumbPath = path.join(seriesDir, `${safeTitle}_thumbnail.jpg`);
      const folderJpgPath = path.join(seriesDir, 'folder.jpg');
      const folderIcoPath = path.join(seriesDir, 'folder.ico');
      const desktopIniPath = path.join(seriesDir, 'desktop.ini');

      let hasCover = false;
      try {
        const st = await fsp.stat(coverJpgPath);
        hasCover = st.isFile() && st.size > 0;
      } catch {
        hasCover = false;
      }

      if (!hasCover && coverUrl) {
        const saved = await this._downloadImageAsJpg(coverUrl, coverJpgPath);
        hasCover = Boolean(saved);
      }

      if (!hasCover && fallbackVideoPath) {
        const extracted = await this._extractFrameAsJpg(fallbackVideoPath, coverJpgPath);
        hasCover = Boolean(extracted);
      }

      if (!hasCover) {
        return { coverJpgPath: null, namedThumbPath: null, folderIcoPath: null };
      }

      // Save reusable named series thumbnail (<safeTitle>_thumbnail.jpg) and folder.jpg
      for (const copyTarget of [namedThumbPath, folderJpgPath]) {
        try {
          const st = await fsp.stat(copyTarget).catch(() => null);
          if (!st || st.size === 0) {
            await fsp.copyFile(coverJpgPath, copyTarget);
          }
        } catch {
          // Ignore copy errors
        }
      }

      // Generate 256x256 Windows .ico from cover.jpg for custom folder icon
      let hasIco = false;
      try {
        const icoSt = await fsp.stat(folderIcoPath);
        hasIco = icoSt.isFile() && icoSt.size > 0;
      } catch {
        hasIco = false;
      }

      if (!hasIco) {
        const ffmpegBin = resolveFfmpegPath();
        if (ffmpegBin && fs.existsSync(ffmpegBin)) {
          if (process.platform === 'win32' && fs.existsSync(folderIcoPath)) {
            await runExec('attrib', ['-h', '-s', '-r', folderIcoPath]).catch(() => {});
          }
          await runExec(ffmpegBin, [
            '-hide_banner',
            '-loglevel',
            'error',
            '-nostdin',
            '-y',
            '-i',
            coverJpgPath,
            '-vf',
            'scale=256:256:force_original_aspect_ratio=decrease,format=rgba,pad=256:256:(ow-iw)/2:(oh-ih)/2:color=0x00000000',
            '-c:v',
            'png',
            '-f',
            'ico',
            folderIcoPath,
          ]).catch(() => {});
          hasIco = fs.existsSync(folderIcoPath);
        }
      }

      // Remove any legacy per-episode _EPS_XXX.jpg files in the series folder
      try {
        const entries = await fsp.readdir(seriesDir);
        for (const entryName of entries) {
          if (/_EPS_\d+\.jpg$/i.test(entryName)) {
            await fsp.rm(path.join(seriesDir, entryName), { force: true }).catch(() => {});
          }
        }
      } catch {
        // Ignore readdir cleanup errors
      }

      // Configure desktop.ini and Windows folder attributes so Explorer shows thumbnail icon
      if (hasIco) {
        const iniExists = fs.existsSync(desktopIniPath);
        if (!iniExists) {
          if (process.platform === 'win32') {
            await runExec('attrib', ['-h', '-s', '-r', desktopIniPath]).catch(() => {});
          }
          const iniContent = [
            '[.ShellClassInfo]',
            'IconResource=folder.ico,0',
            'IconFile=folder.ico',
            'IconIndex=0',
            '[ViewState]',
            'Mode=',
            'Vid=',
            'FolderType=Videos',
            'Logo=folder.jpg',
            '',
          ].join('\r\n');
          await fsp.writeFile(desktopIniPath, iniContent, 'utf8').catch(() => {});
        }

        if (process.platform === 'win32') {
          await runExec('attrib', ['+h', '+s', desktopIniPath]).catch(() => {});
          await runExec('attrib', ['+h', '+s', folderIcoPath]).catch(() => {});
          await runExec('attrib', ['+h', '+s', folderJpgPath]).catch(() => {});
          await runExec('attrib', ['+r', seriesDir]).catch(() => {});
        }
      }

      return {
        coverJpgPath,
        namedThumbPath,
        folderIcoPath: hasIco ? folderIcoPath : null,
      };
    })().finally(() => {
      this._folderSetupPromises.delete(dirKey);
    });

    this._folderSetupPromises.set(dirKey, promise);
    return promise;
  }

  /**
   * Downloads a single episode to <outputDir>/<safeSeriesTitle>/<safeSeriesTitle>_EPS_<paddedNumber>.mp4
   * and saves the series thumbnail image while setting the folder's custom thumbnail icon.
   */
  async downloadEpisode(options, onProgress) {
    const {
      seriesId,
      seriesTitle,
      seriesCover,
      episodeId,
      episodeNumber,
      episodeCover,
      quality = 'best',
      outputDir,
      signal,
    } = options;

    if (!NUMERIC_ID_RE.test(String(seriesId || '')) || !NUMERIC_ID_RE.test(String(episodeId || ''))) {
      throw createAppError('INVALID_ID', 'លេខសម្គាល់រឿង ឬភាគមិនត្រឹមត្រូវ');
    }
    if (!outputDir) {
      throw createAppError('INVALID_DIR', 'សូមជ្រើសរើសថតសម្រាប់រក្សាទុកវីដេអូ');
    }
    if (signal && signal.aborted) {
      throw createAppError('ABORTED', 'ការទាញយកត្រូវបានបោះបង់');
    }

    const safeTitle = safeFileName(seriesTitle, `Hongguo_${seriesId}`);
    const seriesDir = path.join(outputDir, safeTitle);
    await fsp.mkdir(seriesDir, { recursive: true });

    const covers = await this._resolveCovers(seriesId, episodeId, seriesCover, episodeCover);

    const fileName = `${safeTitle}_EPS_${padEpisodeNumber(episodeNumber)}.mp4`;
    const finalPath = path.join(seriesDir, fileName);
    const partPath = `${finalPath}.part.mp4`;

    // Skip if already downloaded cleanly, while still ensuring series thumbnail & folder icon exist
    try {
      const existing = await fsp.stat(finalPath);
      if (existing.isFile() && existing.size > 0) {
        const folderMeta = await this.ensureSeriesFolderThumbnail(
          seriesDir,
          safeTitle,
          covers.seriesCover,
          finalPath
        );
        const thumbnailPath = folderMeta.namedThumbPath || folderMeta.coverJpgPath;
        if (onProgress) {
          onProgress({
            status: 'completed',
            percent: 100,
            downloadedBytes: existing.size,
            totalBytes: existing.size,
            filePath: finalPath,
            thumbnailPath,
          });
        }
        return {
          filePath: finalPath,
          thumbnailPath,
          seriesCoverPath: folderMeta.coverJpgPath,
          folderIconPath: folderMeta.folderIcoPath,
          size: existing.size,
          skipped: true,
        };
      }
    } catch {
      // File does not exist yet
    }

    if (onProgress) {
      onProgress({ status: 'resolving', percent: 0, downloadedBytes: 0, totalBytes: 0 });
    }

    // Prepare series folder thumbnail & custom folder icon in parallel with playback resolution
    const folderThumbPromise = this.ensureSeriesFolderThumbnail(
      seriesDir,
      safeTitle,
      covers.seriesCover,
      null
    ).catch(() => ({ coverJpgPath: null, namedThumbPath: null, folderIcoPath: null }));

    const playback = await this.resolveEpisodePlayback(seriesId, episodeId, quality);
    const candidateUrls = [playback.url, playback.backupUrl].filter(Boolean);
    const useFfmpeg = Boolean(playback.protected || playback.hls || playback.audioUrl);

    let lastErr = null;
    for (const url of candidateUrls) {
      if (signal && signal.aborted) {
        throw createAppError('ABORTED', 'ការទាញយកត្រូវបានបោះបង់');
      }
      try {
        await fsp.rm(partPath, { force: true }).catch(() => {});
        const written = useFfmpeg
          ? await this._downloadWithFfmpeg(playback, url, partPath, signal, onProgress)
          : await this._downloadHttpFile(
              url,
              partPath,
              playback.expectedSize,
              signal,
              onProgress,
              playback.source === 'web'
            );

        await fsp.rename(partPath, finalPath);
        const stat = await fsp.stat(finalPath);

        let folderMeta = await folderThumbPromise;
        if (!folderMeta || !folderMeta.coverJpgPath) {
          folderMeta = await this.ensureSeriesFolderThumbnail(
            seriesDir,
            safeTitle,
            covers.seriesCover,
            finalPath
          );
        }
        const thumbnailPath = folderMeta.namedThumbPath || folderMeta.coverJpgPath;

        if (onProgress) {
          onProgress({
            status: 'completed',
            percent: 100,
            downloadedBytes: stat.size || written,
            totalBytes: stat.size || written,
            filePath: finalPath,
            thumbnailPath,
            definition: playback.definition,
          });
        }
        return {
          filePath: finalPath,
          thumbnailPath,
          seriesCoverPath: folderMeta.coverJpgPath,
          folderIconPath: folderMeta.folderIcoPath,
          size: stat.size || written,
          definition: playback.definition,
          skipped: false,
        };
      } catch (err) {
        await fsp.rm(partPath, { force: true }).catch(() => {});
        if (err && err.code === 'ABORTED') throw err;
        lastErr = err;
      }
    }

    throw lastErr || createAppError('DOWNLOAD_FAILED', 'ទាញយកភាគរឿងបរាជ័យ');
  }
}

module.exports = {
  HongguoService,
  WEB_CATEGORIES,
  NEW_UPDATE_TYPES,
  parseHongguoInput,
  parseRouterDataFromHTML,
  quoteLargeIntegers,
  safeFileName,
  padEpisodeNumber,
  normalizeCoverUrl,
};
