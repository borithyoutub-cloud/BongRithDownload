const path = require('node:path');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const { app, BrowserWindow, Tray, Menu, nativeImage, ipcMain, dialog, shell, clipboard } = require('electron');
const { HongguoService } = require('./hongguo-service');
const { UpdaterService } = require('./updater-service');
const { LicenseService } = require('./license-service');
const pkg = require('../package.json');

const APP_USER_MODEL_ID = 'com.hongguo.minidownloader';
if (process.platform === 'win32') {
  app.setAppUserModelId(APP_USER_MODEL_ID);
}

function getAppVersion() {
  if (app.isPackaged) return app.getVersion();
  return pkg.version || app.getVersion();
}

function getAppRoot() {
  if (app.isPackaged) return app.getAppPath();
  return path.resolve(__dirname, '..');
}

function getAppIconPath() {
  const icoPath = path.join(getAppRoot(), 'assets', 'icon.ico');
  if (fs.existsSync(icoPath)) return icoPath;
  const pngPath = path.join(getAppRoot(), 'assets', 'icon.png');
  return fs.existsSync(pngPath) ? pngPath : undefined;
}

let mainWindow = null;
let appTray = null;
let hongguoService = null;
let updaterService = null;
let licenseService = null;
let settings = null;

const downloadQueue = [];
const activeControllers = new Map();
let activeCount = 0;

function getSettingsPath() {
  return path.join(app.getPath('userData'), 'settings.json');
}

function defaultSettings() {
  return {
    outputDir: path.join(app.getPath('downloads'), 'Hongguo Videos'),
    concurrency: 3,
    quality: 'best',
  };
}

async function loadSettings() {
  const defaults = defaultSettings();
  try {
    const raw = await fsp.readFile(getSettingsPath(), 'utf8');
    const parsed = JSON.parse(raw);
    return {
      outputDir: typeof parsed.outputDir === 'string' && parsed.outputDir.trim() ? parsed.outputDir : defaults.outputDir,
      concurrency: Math.min(5, Math.max(1, Number(parsed.concurrency) || defaults.concurrency)),
      quality: typeof parsed.quality === 'string' && parsed.quality ? parsed.quality : defaults.quality,
    };
  } catch {
    return defaults;
  }
}

async function saveSettings(next) {
  settings = {
    outputDir: next.outputDir || settings.outputDir,
    concurrency: Math.min(5, Math.max(1, Number(next.concurrency) || settings.concurrency)),
    quality: next.quality || settings.quality,
  };
  await fsp.mkdir(path.dirname(getSettingsPath()), { recursive: true });
  await fsp.writeFile(getSettingsPath(), JSON.stringify(settings, null, 2), 'utf8');
  return { ...settings };
}

function emitToRenderer(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, payload);
  }
}

function serializeTask(task) {
  return {
    taskId: task.taskId,
    seriesId: task.seriesId,
    seriesTitle: task.seriesTitle,
    seriesCover: task.seriesCover,
    episodeId: task.episodeId,
    episodeNumber: task.episodeNumber,
    episodeCover: task.episodeCover,
    quality: task.quality,
    status: task.status,
    percent: task.percent,
    downloadedBytes: task.downloadedBytes,
    totalBytes: task.totalBytes,
    filePath: task.filePath,
    thumbnailPath: task.thumbnailPath,
    definition: task.definition,
    error: task.error,
    createdAt: task.createdAt,
  };
}

function emitTaskUpdate(task) {
  emitToRenderer('download:progress', serializeTask(task));
}

function pumpQueue() {
  const maxConcurrent = Math.min(5, Math.max(1, (settings && settings.concurrency) || 3));
  while (activeCount < maxConcurrent) {
    const nextTask = downloadQueue.find((t) => t.status === 'queued');
    if (!nextTask) break;
    runTask(nextTask);
  }
}

async function runTask(task) {
  activeCount += 1;
  const controller = new AbortController();
  activeControllers.set(task.taskId, controller);
  task.status = 'resolving';
  task.error = null;
  emitTaskUpdate(task);

  try {
    const result = await hongguoService.downloadEpisode(
      {
        seriesId: task.seriesId,
        seriesTitle: task.seriesTitle,
        seriesCover: task.seriesCover,
        episodeId: task.episodeId,
        episodeNumber: task.episodeNumber,
        episodeCover: task.episodeCover,
        quality: task.quality || settings.quality || 'best',
        outputDir: task.outputDir || settings.outputDir,
        signal: controller.signal,
      },
      (progress) => {
        if (controller.signal.aborted) return;
        task.status = progress.status || 'downloading';
        if (typeof progress.percent === 'number') task.percent = progress.percent;
        if (typeof progress.downloadedBytes === 'number') task.downloadedBytes = progress.downloadedBytes;
        if (typeof progress.totalBytes === 'number') task.totalBytes = progress.totalBytes;
        if (progress.filePath) task.filePath = progress.filePath;
        if (progress.thumbnailPath) task.thumbnailPath = progress.thumbnailPath;
        if (progress.definition) task.definition = progress.definition;
        emitTaskUpdate(task);
      }
    );

    task.status = 'completed';
    task.percent = 100;
    task.filePath = result.filePath;
    if (result.thumbnailPath) task.thumbnailPath = result.thumbnailPath;
    task.downloadedBytes = result.size || task.downloadedBytes;
    task.totalBytes = result.size || task.totalBytes;
    if (result.definition) task.definition = result.definition;
    emitTaskUpdate(task);
  } catch (err) {
    if (controller.signal.aborted || (err && err.code === 'ABORTED')) {
      task.status = 'cancelled';
      task.error = 'បានបោះបង់';
    } else {
      task.status = 'failed';
      task.error = (err && err.message) || 'ទាញយកបរាជ័យ';
    }
    emitTaskUpdate(task);
  } finally {
    activeControllers.delete(task.taskId);
    activeCount = Math.max(0, activeCount - 1);
    pumpQueue();
  }
}

function createWindow() {
  const iconPath = getAppIconPath();
  mainWindow = new BrowserWindow({
    width: 500,
    height: 730,
    minWidth: 440,
    minHeight: 620,
    frame: false,
    backgroundColor: '#0b0b10',
    show: false,
    resizable: true,
    maximizable: false,
    autoHideMenuBar: true,
    icon: iconPath,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (iconPath && process.platform === 'win32') {
    try {
      mainWindow.setIcon(iconPath);
    } catch {
      // Ignore icon error
    }
  }

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.webContents.once('did-finish-load', () => {
    // Silent startup update check 2.5s after UI ready; popup appears ONLY if a new update file exists
    setTimeout(() => {
      if (updaterService) {
        updaterService.checkForUpdates().catch(() => {});
      }
    }, 2500);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function registerIpcHandlers() {
  ipcMain.handle('window:minimize', () => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.minimize();
    return true;
  });

  ipcMain.handle('window:close', () => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.close();
    return true;
  });

  ipcMain.handle('window:toggle-pin', () => {
    if (!mainWindow || mainWindow.isDestroyed()) return false;
    const next = !mainWindow.isAlwaysOnTop();
    mainWindow.setAlwaysOnTop(next);
    return next;
  });

  ipcMain.handle('clipboard:read', () => clipboard.readText());
  ipcMain.handle('clipboard:write', (_event, text) => {
    clipboard.writeText(String(text || ''));
    return true;
  });

  ipcMain.handle('license:status', async () => {
    try {
      const status = await licenseService.getCurrentSessionStatus();
      return { ok: true, data: status };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });

  ipcMain.handle('license:activate', async (_event, keyCode) => {
    try {
      const res = await licenseService.activateKey(keyCode);
      return res;
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });

  ipcMain.handle('license:logout', async () => {
    await licenseService.clearSession();
    return {
      ok: true,
      data: {
        licensed: false,
        machineId: licenseService.machineId,
        license: null,
      },
    };
  });

  ipcMain.handle('shell:open-external', async (_event, url) => {
    try {
      const parsed = new URL(String(url || ''));
      if (
        (parsed.protocol === 'https:' || parsed.protocol === 'http:') &&
        (parsed.hostname === 'hongguoduanju.com' || parsed.hostname.endsWith('.hongguoduanju.com'))
      ) {
        await shell.openExternal(parsed.toString());
        return { ok: true };
      }
      return { ok: false, error: 'អនុញ្ញាតតែតំណភ្ជាប់ hongguoduanju.com ប៉ុណ្ណោះ' };
    } catch {
      return { ok: false, error: 'តំណភ្ជាប់មិនត្រឹមត្រូវ' };
    }
  });

  ipcMain.handle('hongguo:categories', () => ({
    ok: true,
    data: hongguoService.getCategories(),
  }));

  ipcMain.handle('hongguo:new-update-types', () => ({
    ok: true,
    data: hongguoService.getNewUpdateTypes(),
  }));

  ipcMain.handle('hongguo:new-updates', async (_event, { type, cursor } = {}) => {
    try {
      const data = await hongguoService.fetchNewUpdates(type, cursor);
      return { ok: true, data };
    } catch (err) {
      return { ok: false, error: err.message, code: err.code || 'NEW_UPDATES_ERROR' };
    }
  });

  ipcMain.handle('hongguo:browse', async (_event, { categoryId, page } = {}) => {
    try {
      const data = await hongguoService.fetchWebCategory(categoryId, page);
      return { ok: true, data };
    } catch (err) {
      return { ok: false, error: err.message, code: err.code || 'BROWSE_ERROR' };
    }
  });

  ipcMain.handle('hongguo:search', async (_event, query) => {
    try {
      const data = await hongguoService.searchSeries(query);
      return { ok: true, data };
    } catch (err) {
      return { ok: false, error: err.message, code: err.code || 'SEARCH_ERROR' };
    }
  });

  ipcMain.handle('hongguo:fetch-series', async (_event, input) => {
    try {
      const data = await hongguoService.fetchSeriesDetails(input);
      return { ok: true, data };
    } catch (err) {
      return { ok: false, error: err.message, code: err.code || 'FETCH_ERROR' };
    }
  });

  ipcMain.handle('downloads:enqueue', async (_event, payload) => {
    const { seriesId, seriesTitle, seriesCover, episodes, quality } = payload || {};
    if (!seriesId || !Array.isArray(episodes) || episodes.length === 0) {
      return { ok: false, error: 'សូមជ្រើសរើសយ៉ាងហោចណាស់មួយភាគ' };
    }

    await fsp.mkdir(settings.outputDir, { recursive: true }).catch(() => {});
    const sortedEpisodes = [...episodes].sort((a, b) => (Number(a.number) || 0) - (Number(b.number) || 0));
    const added = [];
    for (const ep of sortedEpisodes) {
      const epId = String(ep.id);
      const existingTask = downloadQueue.find((t) => t.episodeId === epId);
      if (existingTask) {
        if (existingTask.status === 'failed' || existingTask.status === 'cancelled') {
          existingTask.status = 'queued';
          existingTask.percent = 0;
          existingTask.error = null;
          existingTask.quality = quality || settings.quality || 'best';
          existingTask.outputDir = settings.outputDir;
          if (seriesCover) existingTask.seriesCover = seriesCover;
          emitTaskUpdate(existingTask);
        }
        added.push(serializeTask(existingTask));
        continue;
      }

      const task = {
        taskId: `${seriesId}_${epId}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        seriesId: String(seriesId),
        seriesTitle: seriesTitle || String(seriesId),
        seriesCover: seriesCover || '',
        episodeId: epId,
        episodeNumber: Number(ep.number) || 1,
        episodeCover: ep.cover || seriesCover || '',
        quality: quality || settings.quality || 'best',
        outputDir: settings.outputDir,
        status: 'queued',
        percent: 0,
        downloadedBytes: 0,
        totalBytes: 0,
        filePath: null,
        thumbnailPath: null,
        definition: null,
        error: null,
        createdAt: Date.now(),
      };
      downloadQueue.push(task);
      emitTaskUpdate(task);
      added.push(serializeTask(task));
    }

    pumpQueue();
    return { ok: true, data: added };
  });

  ipcMain.handle('downloads:list', () => ({
    ok: true,
    data: downloadQueue.map(serializeTask),
  }));

  ipcMain.handle('downloads:cancel', (_event, taskId) => {
    const task = downloadQueue.find((t) => t.taskId === taskId);
    if (!task) return { ok: false };
    const ctrl = activeControllers.get(taskId);
    if (ctrl) {
      ctrl.abort();
    } else if (task.status === 'queued') {
      task.status = 'cancelled';
      task.error = 'បានបោះបង់';
      emitTaskUpdate(task);
    }
    return { ok: true };
  });

  ipcMain.handle('downloads:cancel-series', (_event, seriesId) => {
    const targetId = String(seriesId || '');
    for (const task of downloadQueue) {
      if (String(task.seriesId) !== targetId) continue;
      const ctrl = activeControllers.get(task.taskId);
      if (ctrl) {
        ctrl.abort();
      } else if (task.status === 'queued') {
        task.status = 'cancelled';
        task.error = 'បានបោះបង់';
        emitTaskUpdate(task);
      }
    }
    return { ok: true };
  });

  ipcMain.handle('downloads:retry', (_event, taskId) => {
    const task = downloadQueue.find((t) => t.taskId === taskId);
    if (!task) return { ok: false };
    if (task.status === 'failed' || task.status === 'cancelled') {
      task.status = 'queued';
      task.percent = 0;
      task.error = null;
      task.outputDir = settings.outputDir;
      emitTaskUpdate(task);
      pumpQueue();
    }
    return { ok: true };
  });

  ipcMain.handle('downloads:retry-series', (_event, seriesId) => {
    const targetId = String(seriesId || '');
    for (const task of downloadQueue) {
      if (String(task.seriesId) !== targetId) continue;
      if (task.status === 'failed' || task.status === 'cancelled') {
        task.status = 'queued';
        task.percent = 0;
        task.error = null;
        task.outputDir = settings.outputDir;
        emitTaskUpdate(task);
      }
    }
    pumpQueue();
    return { ok: true };
  });

  ipcMain.handle('downloads:clear-finished', () => {
    for (let i = downloadQueue.length - 1; i >= 0; i -= 1) {
      const s = downloadQueue[i].status;
      if (s === 'completed' || s === 'failed' || s === 'cancelled') {
        downloadQueue.splice(i, 1);
      }
    }
    return { ok: true, data: downloadQueue.map(serializeTask) };
  });

  ipcMain.handle('downloads:open-file', async (_event, filePath) => {
    if (!filePath || !fs.existsSync(filePath)) {
      return { ok: false, error: 'រកមិនឃើញឯកសារវីដេអូទេ' };
    }
    const errStr = await shell.openPath(filePath);
    return errStr ? { ok: false, error: errStr } : { ok: true };
  });

  ipcMain.handle('downloads:show-in-folder', (_event, filePath) => {
    if (filePath && fs.existsSync(filePath)) {
      shell.showItemInFolder(filePath);
      return { ok: true };
    }
    if (settings && settings.outputDir && fs.existsSync(settings.outputDir)) {
      shell.openPath(settings.outputDir);
      return { ok: true };
    }
    return { ok: false };
  });

  ipcMain.handle('settings:get', () => ({
    ok: true,
    data: { ...settings },
  }));

  ipcMain.handle('settings:choose-dir', async () => {
    const res = await dialog.showOpenDialog(mainWindow, {
      title: 'ជ្រើសរើសថតរក្សាទុកវីដេអូ',
      defaultPath: settings.outputDir,
      properties: ['openDirectory', 'createDirectory'],
    });
    if (res.canceled || !res.filePaths || !res.filePaths[0]) {
      return { ok: true, data: { ...settings }, canceled: true };
    }
    const updated = await saveSettings({ outputDir: res.filePaths[0] });
    return { ok: true, data: updated, canceled: false };
  });

  ipcMain.handle('settings:update', async (_event, partial) => {
    const updated = await saveSettings(partial || {});
    pumpQueue();
    return { ok: true, data: updated };
  });

  ipcMain.handle('updater:get-info', () => ({
    ok: true,
    data: {
      currentVersion: getAppVersion(),
      updateDirs: updaterService ? updaterService.updateDirs : [],
      pendingUpdate: updaterService ? updaterService._pendingUpdate : null,
    },
  }));

  ipcMain.handle('updater:check', async () => {
    if (!updaterService) return { ok: true, data: { updateAvailable: false, update: null } };
    const res = await updaterService.checkForUpdates({ forceEmit: true });
    return { ok: true, data: res };
  });

  ipcMain.handle('updater:install', async () => {
    try {
      const res = await updaterService.downloadAndInstallUpdate();
      return { ok: true, data: res };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });
}

async function cleanupLegacyEpisodeJpgs(baseDir) {
  if (!baseDir) return;
  try {
    const entries = await fsp.readdir(baseDir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const subDir = path.join(baseDir, entry.name);
      const files = await fsp.readdir(subDir).catch(() => []);
      for (const fileName of files) {
        if (/_EPS_\d+\.jpg$/i.test(fileName)) {
          await fsp.rm(path.join(subDir, fileName), { force: true }).catch(() => {});
        }
      }
    }
  } catch {
    // Ignore cleanup errors
  }
}

function createTray() {
  if (appTray) return;
  const iconPath = getAppIconPath();
  if (!iconPath) return;

  try {
    const trayImg = nativeImage.createFromPath(iconPath);
    appTray = new Tray(trayImg);
    appTray.setToolTip('ហុងហ្គោ ដោនឡូត — Hongguo Mini Downloader');

    const contextMenu = Menu.buildFromTemplate([
      {
        label: 'បង្ហាញកម្មវិធី (Show App)',
        click: () => {
          if (mainWindow && !mainWindow.isDestroyed()) {
            if (mainWindow.isMinimized()) mainWindow.restore();
            mainWindow.show();
            mainWindow.focus();
          }
        },
      },
      {
        label: 'បើកថតរក្សាទុកវីដេអូ (Open Folder)',
        click: () => {
          if (settings && settings.outputDir && fs.existsSync(settings.outputDir)) {
            shell.openPath(settings.outputDir);
          }
        },
      },
      { type: 'separator' },
      {
        label: 'បិទកម្មវិធី (Quit)',
        click: () => {
          app.quit();
        },
      },
    ]);

    appTray.setContextMenu(contextMenu);
    appTray.on('click', () => {
      if (!mainWindow || mainWindow.isDestroyed()) return;
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.show();
      mainWindow.focus();
    });
  } catch {
    // Ignore tray creation error
  }
}

function ensureWindowsShortcuts() {
  if (process.platform !== 'win32' || typeof shell.writeShortcutLink !== 'function') return;
  const iconPath = getAppIconPath();
  if (!iconPath) return;

  const rootDir = getAppRoot();
  const shortcutOptions = {
    target: process.execPath,
    args: app.isPackaged ? '' : `"${rootDir}."`,
    cwd: rootDir,
    description: 'ហុងហ្គោ ដោនឡូត — Hongguo Mini Downloader',
    icon: iconPath,
    iconIndex: 0,
    appUserModelId: APP_USER_MODEL_ID,
  };

  const candidates = [
    path.join(rootDir, 'Hongguo Downloader.lnk'),
    path.join(app.getPath('desktop'), 'ហុងហ្គោ ដោនឡូត (Hongguo Downloader).lnk'),
  ];

  for (const lnkPath of candidates) {
    try {
      const op = fs.existsSync(lnkPath) ? 'update' : 'create';
      const ok = shell.writeShortcutLink(lnkPath, op, shortcutOptions);
      if (!ok) {
        shell.writeShortcutLink(lnkPath, 'create', shortcutOptions);
      }
    } catch {
      // Ignore shortcut creation errors
    }
  }

  // Also create shortcut for the separate Admin Key Manager tool
  const kmScript = path.join(rootDir, 'src', 'key-manager-main.js');
  if (fs.existsSync(kmScript)) {
    const kmOptions = {
      target: process.execPath,
      args: `"${kmScript}"`,
      cwd: rootDir,
      description: 'កម្មវិធីគ្រប់គ្រងកូដអាជ្ញាប័ណ្ណ — Hongguo Key Manager',
      icon: iconPath,
      iconIndex: 0,
      appUserModelId: 'com.hongguo.keymanager',
    };
    const kmLnk = path.join(rootDir, 'Hongguo Key Manager.lnk');
    try {
      const op = fs.existsSync(kmLnk) ? 'update' : 'create';
      const ok = shell.writeShortcutLink(kmLnk, op, kmOptions);
      if (!ok) shell.writeShortcutLink(kmLnk, 'create', kmOptions);
    } catch {
      // Ignore shortcut creation errors
    }
  }
}

function loadReleaseConfig() {
  const candidates = [
    path.join(getAppRoot(), 'config', 'release-config.json'),
    path.join(path.dirname(process.execPath), 'release-config.json'),
  ];
  for (const cfgPath of candidates) {
    try {
      if (fs.existsSync(cfgPath)) {
        return JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
      }
    } catch {
      // Ignore malformed config
    }
  }
  return {};
}

app.whenReady().then(async () => {
  settings = await loadSettings();
  const relCfg = loadReleaseConfig();
  cleanupLegacyEpisodeJpgs(settings.outputDir).catch(() => {});
  ensureWindowsShortcuts();

  const workspaceDbPath = path.join(getAppRoot(), 'data', 'licenses.json');
  const licenseDbPath = fs.existsSync(workspaceDbPath)
    ? workspaceDbPath
    : path.join(app.getPath('userData'), 'licenses.json');

  licenseService = new LicenseService({
    dbPath: licenseDbPath,
    sessionPath: path.join(app.getPath('userData'), 'license-session.json'),
    useGlobalPersistence: true,
    remoteServerUrl:
      process.env.HONGGUO_LICENSE_SERVER_URL || relCfg.licenseServerUrl || '',
  });
  hongguoService = new HongguoService({
    profilePath: path.join(app.getPath('userData'), 'anonymous.json'),
  });

  const updateDirs = [
    path.join(getAppRoot(), 'updates'),
    path.join(app.getPath('userData'), 'updates'),
  ];
  if (app.isPackaged) {
    updateDirs.unshift(path.join(path.dirname(process.execPath), 'updates'));
  }

  let onlineFeedUrl = process.env.HONGGUO_UPDATE_URL || relCfg.updateFeedUrl || '';
  if (!onlineFeedUrl && relCfg.githubReleasesRepo) {
    onlineFeedUrl = `https://api.github.com/repos/${String(relCfg.githubReleasesRepo).trim()}/releases/latest`;
  }

  updaterService = new UpdaterService({
    currentVersion: getAppVersion(),
    updateDirs,
    feedUrl: onlineFeedUrl,
    githubRepo: relCfg.githubReleasesRepo || 'borithyoutub-cloud/BongRithDownload',
    appRootDir: getAppRoot(),
    stagingDir: path.join(app.getPath('userData'), 'pending-updates'),
    appUpdateConfigPath: path.join(process.resourcesPath || app.getAppPath(), 'app-update.yml'),
    openFileFn: (filePath) => shell.openPath(filePath),
    relaunchAppFn: () => {
      app.relaunch();
      app.exit(0);
    },
  });

  updaterService.on('update-available', (info) => {
    emitToRenderer('updater:update-available', info);
  });

  updaterService.on('download-progress', (prog) => {
    emitToRenderer('updater:progress', prog);
  });

  updaterService.startWatching();
  registerIpcHandlers();
  createWindow();
  createTray();

  const updInterval = setInterval(() => {
    updaterService.checkForUpdates().catch(() => {});
  }, 45000);
  if (typeof updInterval.unref === 'function') updInterval.unref();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (updaterService) updaterService.stopWatching();
  if (appTray) {
    try {
      appTray.destroy();
    } catch {
      // Ignore destroy error
    }
    appTray = null;
  }
  for (const ctrl of activeControllers.values()) {
    ctrl.abort();
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
