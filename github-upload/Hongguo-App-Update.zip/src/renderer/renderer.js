const state = {
  activeTab: 'episodes',
  series: null,
  selectedEpisodes: new Set(),
  tasksById: new Map(),
  latestTaskByEpisodeId: new Map(),
  browseCategory: 'real-drama',
  browsePage: 1,
  browseHasMore: false,
  browseLoaded: false,
  browseItems: [],
  categories: [],
  newUpdateTypes: [],
  newUpdateType: 'new-calendar',
  newUpdateCursor: '',
  newUpdateHasMore: false,
  newUpdateLoaded: false,
  newUpdateItems: [],
  settings: {
    outputDir: '',
    concurrency: 3,
    quality: 'best',
  },
  pendingUpdate: null,
  toastTimer: null,
};

const el = {
  pinBtn: document.getElementById('pinBtn'),
  minBtn: document.getElementById('minBtn'),
  closeBtn: document.getElementById('closeBtn'),
  urlInputBox: document.getElementById('urlInputBox'),
  urlInput: document.getElementById('urlInput'),
  pasteBtn: document.getElementById('pasteBtn'),
  fetchBtn: document.getElementById('fetchBtn'),
  tabButtons: Array.from(document.querySelectorAll('.tab-btn')),
  tabPanels: {
    episodes: document.getElementById('tab-episodes'),
    'new-updates': document.getElementById('tab-new-updates'),
    browse: document.getElementById('tab-browse'),
    downloads: document.getElementById('tab-downloads'),
  },
  activeQueueBadge: document.getElementById('activeQueueBadge'),

  episodesEmpty: document.getElementById('episodesEmpty'),
  episodesLoading: document.getElementById('episodesLoading'),
  seriesWorkspace: document.getElementById('seriesWorkspace'),
  goNewUpdatesBtn: document.getElementById('goNewUpdatesBtn'),
  goBrowseBtn: document.getElementById('goBrowseBtn'),

  seriesCover: document.getElementById('seriesCover'),
  seriesTitle: document.getElementById('seriesTitle'),
  seriesSourceLink: document.getElementById('seriesSourceLink'),
  seriesEpCount: document.getElementById('seriesEpCount'),
  seriesTags: document.getElementById('seriesTags'),
  seriesDesc: document.getElementById('seriesDesc'),
  searchMatchesWrap: document.getElementById('searchMatchesWrap'),
  searchMatchesList: document.getElementById('searchMatchesList'),

  qualitySelect: document.getElementById('qualitySelect'),
  rangeStartInput: document.getElementById('rangeStartInput'),
  rangeEndInput: document.getElementById('rangeEndInput'),
  applyRangeBtn: document.getElementById('applyRangeBtn'),
  selectAllBtn: document.getElementById('selectAllBtn'),
  clearSelectBtn: document.getElementById('clearSelectBtn'),
  downloadSelectedBtn: document.getElementById('downloadSelectedBtn'),
  epsGrid: document.getElementById('epsGrid'),

  categoryPills: document.getElementById('categoryPills'),
  browseGrid: document.getElementById('browseGrid'),
  browseLoading: document.getElementById('browseLoading'),
  loadMoreBrowseBtn: document.getElementById('loadMoreBrowseBtn'),

  newUpdateTypePills: document.getElementById('newUpdateTypePills'),
  refreshNewUpdatesBtn: document.getElementById('refreshNewUpdatesBtn'),
  newUpdatesGrid: document.getElementById('newUpdatesGrid'),
  newUpdatesLoading: document.getElementById('newUpdatesLoading'),
  loadMoreNewUpdatesBtn: document.getElementById('loadMoreNewUpdatesBtn'),

  openOutputFolderBtn: document.getElementById('openOutputFolderBtn'),
  clearFinishedBtn: document.getElementById('clearFinishedBtn'),
  downloadQueueList: document.getElementById('downloadQueueList'),
  queueEmpty: document.getElementById('queueEmpty'),
  outputDirDisplay: document.getElementById('outputDirDisplay'),
  chooseDirBtn: document.getElementById('chooseDirBtn'),
  concurrencySelect: document.getElementById('concurrencySelect'),
  appVersionText: document.getElementById('appVersionText'),
  manualCheckUpdateBtn: document.getElementById('manualCheckUpdateBtn'),
  manualUpdateStatus: document.getElementById('manualUpdateStatus'),

  licenseHeaderBadge: document.getElementById('licenseHeaderBadge'),
  licensePlanInfoText: document.getElementById('licensePlanInfoText'),
  logoutLicenseBtn: document.getElementById('logoutLicenseBtn'),
  licenseGateModal: document.getElementById('licenseGateModal'),
  gateMachineId: document.getElementById('gateMachineId'),
  copyMachineIdBtn: document.getElementById('copyMachineIdBtn'),
  licenseKeyInput: document.getElementById('licenseKeyInput'),
  pasteLicenseKeyBtn: document.getElementById('pasteLicenseKeyBtn'),
  licenseErrorText: document.getElementById('licenseErrorText'),
  activateLicenseBtn: document.getElementById('activateLicenseBtn'),

  toast: document.getElementById('toast'),

  titlebarUpdateBtn: document.getElementById('titlebarUpdateBtn'),
  mainUpdateBanner: document.getElementById('mainUpdateBanner'),
  mainUpdateTitle: document.getElementById('mainUpdateTitle'),
  mainUpdateBadge: document.getElementById('mainUpdateBadge'),
  mainUpdateNotes: document.getElementById('mainUpdateNotes'),
  mainInstallUpdateBtn: document.getElementById('mainInstallUpdateBtn'),
  mainUpdateProgressWrap: document.getElementById('mainUpdateProgressWrap'),
  mainUpdateProgressFill: document.getElementById('mainUpdateProgressFill'),
  mainUpdateProgressText: document.getElementById('mainUpdateProgressText'),

  updateModal: document.getElementById('updateModal'),
  updateVersionBadge: document.getElementById('updateVersionBadge'),
  updateFileMeta: document.getElementById('updateFileMeta'),
  updateReleaseNotes: document.getElementById('updateReleaseNotes'),
  updateProgressWrap: document.getElementById('updateProgressWrap'),
  updateProgressFill: document.getElementById('updateProgressFill'),
  updateProgressText: document.getElementById('updateProgressText'),
  remindLaterBtn: document.getElementById('remindLaterBtn'),
  installUpdateBtn: document.getElementById('installUpdateBtn'),
};

function showToast(message, type = 'info') {
  if (!el.toast) return;
  if (state.toastTimer) clearTimeout(state.toastTimer);
  el.toast.textContent = message;
  el.toast.className = `toast ${type}`;
  state.toastTimer = setTimeout(() => {
    el.toast.classList.add('hidden');
  }, 4200);
}

function formatBytes(bytes) {
  const n = Number(bytes) || 0;
  if (n <= 0) return '';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function statusLabelKm(task) {
  if (!task) return 'រួចរាល់សម្រាប់ទាញយក';
  switch (task.status) {
    case 'queued':
      return 'រង់ចាំ...';
    case 'resolving':
      return 'កំពុងភ្ជាប់...';
    case 'downloading':
      return task.percent > 0 ? `កំពុងទាញយក ${task.percent}%` : 'កំពុងទាញយក...';
    case 'completed':
      return 'រួចរាល់ ✓';
    case 'failed':
      return 'បរាជ័យ ✕';
    case 'cancelled':
      return 'បានបោះបង់';
    default:
      return '';
  }
}

function switchTab(tabName) {
  state.activeTab = tabName;
  for (const btn of el.tabButtons) {
    const active = btn.dataset.tab === tabName;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-selected', String(active));
  }
  for (const [name, panel] of Object.entries(el.tabPanels)) {
    panel.classList.toggle('active', name === tabName);
  }
  if (tabName === 'new-updates' && !state.newUpdateLoaded) {
    loadNewUpdates(state.newUpdateType, '', false);
  } else if (tabName === 'browse' && !state.browseLoaded) {
    loadBrowseCategory(state.browseCategory, 1, false);
  }
}

function setFetchLoading(isLoading) {
  el.fetchBtn.disabled = isLoading;
  el.fetchBtn.querySelector('.btn-label').textContent = isLoading ? 'កំពុងទាញ...' : 'ទាញយកទិន្នន័យ';
  el.fetchBtn.querySelector('.btn-spinner').classList.toggle('hidden', !isLoading);

  if (isLoading) {
    el.episodesEmpty.classList.add('hidden');
    el.seriesWorkspace.classList.add('hidden');
    el.episodesLoading.classList.remove('hidden');
  } else {
    el.episodesLoading.classList.add('hidden');
  }
}

function updateSelectedButton() {
  const count = state.selectedEpisodes.size;
  el.downloadSelectedBtn.textContent = `ទាញយកភាគដែលបានជ្រើស (${count})`;
  el.downloadSelectedBtn.disabled = count === 0 || !state.series;
}

function renderSeriesWorkspace(series) {
  state.series = series;
  state.selectedEpisodes.clear();

  el.episodesEmpty.classList.add('hidden');
  el.episodesLoading.classList.add('hidden');
  el.seriesWorkspace.classList.remove('hidden');

  el.seriesTitle.textContent = series.title || series.id;
  el.seriesEpCount.textContent = `សរុប ${series.episodes.length} ភាគ`;
  el.seriesDesc.textContent = series.description || 'រឿងភាគពីគេហទំព័រផ្លូវការ https://hongguoduanju.com/';

  if (series.cover) {
    el.seriesCover.src = series.cover;
    el.seriesCover.onerror = () => {
      el.seriesCover.removeAttribute('src');
    };
  } else {
    el.seriesCover.removeAttribute('src');
  }

  el.seriesTags.innerHTML = '';
  for (const tag of (series.tags || []).slice(0, 4)) {
    const chip = document.createElement('span');
    chip.className = 'tag-chip';
    chip.textContent = tag;
    el.seriesTags.appendChild(chip);
  }

  if (Array.isArray(series.searchMatches) && series.searchMatches.length > 1) {
    el.searchMatchesWrap.classList.remove('hidden');
    el.searchMatchesList.innerHTML = '';
    for (const m of series.searchMatches.slice(0, 6)) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `match-pill${m.id === series.id ? ' active' : ''}`;
      btn.textContent = m.title;
      btn.addEventListener('click', () => loadSeriesFromInput(m.id));
      el.searchMatchesList.appendChild(btn);
    }
  } else {
    el.searchMatchesWrap.classList.add('hidden');
  }

  const maxEp = series.episodes.length;
  el.rangeStartInput.value = '1';
  el.rangeStartInput.max = String(Math.max(1, maxEp));
  el.rangeEndInput.value = String(Math.max(1, maxEp));
  el.rangeEndInput.max = String(Math.max(1, maxEp));

  if (series.targetEpisodeId) {
    state.selectedEpisodes.add(String(series.targetEpisodeId));
  }

  renderEpisodesGrid();
  updateSelectedButton();
}

function renderEpisodesGrid() {
  if (!state.series) return;
  el.epsGrid.innerHTML = '';

  const targetId = state.series.targetEpisodeId ? String(state.series.targetEpisodeId) : null;
  let targetEl = null;

  for (const ep of state.series.episodes) {
    const epId = String(ep.id);
    const task = state.latestTaskByEpisodeId.get(epId);
    const isSelected = state.selectedEpisodes.has(epId);

    const pill = document.createElement('div');
    pill.className = 'ep-pill';
    pill.dataset.episodeId = epId;
    if (isSelected) pill.classList.add('selected');
    if (targetId && epId === targetId) {
      pill.classList.add('target-highlight');
      targetEl = pill;
    }
    if (task) pill.classList.add(task.status);

    const info = document.createElement('div');
    info.className = 'ep-info';

    const label = document.createElement('span');
    label.className = 'ep-label';
    label.textContent = `ភាគ ${String(ep.number).padStart(2, '0')}`;

    const status = document.createElement('span');
    status.className = 'ep-status';
    status.textContent = task ? statusLabelKm(task) : ep.playable === false ? 'ត្រូវការ App' : 'ចុចជ្រើស';

    info.appendChild(label);
    info.appendChild(status);

    const quickBtn = document.createElement('button');
    quickBtn.type = 'button';
    quickBtn.className = 'ep-quick-dl';
    quickBtn.title = 'ទាញយកភាគនេះភ្លាម';
    quickBtn.innerHTML =
      '<svg viewBox="0 0 24 24" fill="none"><path d="M12 4v11m0 0l-4-4m4 4l4-4M5 19h14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

    quickBtn.addEventListener('click', async (event) => {
      event.stopPropagation();
      await enqueueEpisodeList([ep]);
    });

    const progBar = document.createElement('div');
    progBar.className = 'ep-progress-bar';
    const progFill = document.createElement('div');
    progFill.className = 'ep-progress-fill';
    progFill.style.width = `${task ? task.percent : 0}%`;
    progBar.appendChild(progFill);

    pill.appendChild(info);
    pill.appendChild(quickBtn);
    pill.appendChild(progBar);

    pill.addEventListener('click', () => {
      if (state.selectedEpisodes.has(epId)) {
        state.selectedEpisodes.delete(epId);
        pill.classList.remove('selected');
      } else {
        state.selectedEpisodes.add(epId);
        pill.classList.add('selected');
      }
      updateSelectedButton();
    });

    el.epsGrid.appendChild(pill);
  }

  if (targetEl) {
    setTimeout(() => targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' }), 80);
  }
}

function updateEpisodePillProgress(task) {
  if (!el.epsGrid) return;
  const pill = el.epsGrid.querySelector(`.ep-pill[data-episode-id="${CSS.escape(String(task.episodeId))}"]`);
  if (!pill) return;

  pill.classList.remove('queued', 'resolving', 'downloading', 'completed', 'failed', 'cancelled');
  pill.classList.add(task.status);

  const statusEl = pill.querySelector('.ep-status');
  const fillEl = pill.querySelector('.ep-progress-fill');
  if (statusEl) statusEl.textContent = statusLabelKm(task);
  if (fillEl) fillEl.style.width = `${task.status === 'completed' ? 100 : task.percent || 0}%`;
}

async function loadSeriesFromInput(rawInput) {
  const value = String(rawInput ?? el.urlInput.value).trim();
  if (!value) {
    el.urlInputBox.classList.remove('shake');
    void el.urlInputBox.offsetWidth;
    el.urlInputBox.classList.add('shake');
    showToast('សូមបិទភ្ជាប់តំណពី https://hongguoduanju.com/ ឬបញ្ចូលឈ្មោះរឿង!', 'error');
    return;
  }

  switchTab('episodes');
  setFetchLoading(true);
  try {
    const res = await window.hongguoAPI.fetchSeriesDetails(value);
    if (!res.ok) {
      el.episodesEmpty.classList.toggle('hidden', Boolean(state.series));
      el.seriesWorkspace.classList.toggle('hidden', !state.series);
      if (res.code === 'INVALID_SOURCE') {
        el.urlInputBox.classList.remove('shake');
        void el.urlInputBox.offsetWidth;
        el.urlInputBox.classList.add('shake');
      }
      showToast(res.error || 'មិនអាចទាញយកទិន្នន័យរឿងបានទេ', 'error');
      return;
    }

    renderSeriesWorkspace(res.data);
  } catch (err) {
    el.episodesEmpty.classList.toggle('hidden', Boolean(state.series));
    el.seriesWorkspace.classList.toggle('hidden', !state.series);
    showToast(err.message || 'មានបញ្ហាក្នុងការតភ្ជាប់', 'error');
  } finally {
    setFetchLoading(false);
  }
}

async function enqueueEpisodeList(episodes) {
  if (!state.series || !Array.isArray(episodes) || episodes.length === 0) return;

  const quality = el.qualitySelect.value || state.settings.quality || 'best';
  const res = await window.hongguoAPI.enqueueDownloads({
    seriesId: state.series.id,
    seriesTitle: state.series.title,
    seriesCover: state.series.cover || '',
    episodes,
    quality,
  });

  if (!res.ok) {
    showToast(res.error || 'មិនអាចបន្ថែមទៅបញ្ជីទាញយកបានទេ', 'error');
    return;
  }

  for (const task of res.data) {
    state.tasksById.set(task.taskId, task);
    state.latestTaskByEpisodeId.set(String(task.episodeId), task);
    updateEpisodePillProgress(task);
  }

  renderDownloadQueue();
  // Automatically switch to the Downloads tab so the user sees the 1-card batch download progress
  switchTab('downloads');
  showToast(`បានចាប់ផ្តើមទាញយក ${episodes.length} ភាគ!`, 'success');
}

function renderNewUpdateTypes() {
  if (!el.newUpdateTypePills) return;
  el.newUpdateTypePills.innerHTML = '';
  for (const item of state.newUpdateTypes) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `cat-pill${item.id === state.newUpdateType ? ' active' : ''}`;
    btn.textContent = item.nameKm;
    btn.addEventListener('click', () => {
      if (state.newUpdateType === item.id && state.newUpdateItems.length > 0) return;
      loadNewUpdates(item.id, '', false);
    });
    el.newUpdateTypePills.appendChild(btn);
  }
}

async function loadNewUpdates(type = 'new-calendar', cursor = '', append = false) {
  state.newUpdateType = type;
  renderNewUpdateTypes();

  if (!append) {
    el.newUpdatesGrid.innerHTML = '';
    state.newUpdateItems = [];
    state.newUpdateCursor = '';
  }
  el.newUpdatesLoading.classList.remove('hidden');
  el.loadMoreNewUpdatesBtn.classList.add('hidden');

  try {
    const res = await window.hongguoAPI.fetchNewUpdates(type, cursor);
    if (!res.ok) {
      showToast(res.error || 'មិនអាចផ្ទុករឿងទើបចេញថ្មីបានទេ', 'error');
      return;
    }

    state.newUpdateLoaded = true;
    state.newUpdateHasMore = Boolean(res.data.hasMore);
    state.newUpdateCursor = res.data.nextCursor || '';
    const newItems = res.data.items || [];
    state.newUpdateItems.push(...newItems);

    for (const item of newItems) {
      const card = document.createElement('div');
      card.className = 'browse-card';

      const poster = document.createElement('div');
      poster.className = 'browse-poster';

      if (item.cover) {
        const img = document.createElement('img');
        img.src = item.cover;
        img.alt = '';
        img.loading = 'lazy';
        img.onerror = () => img.remove();
        poster.appendChild(img);
      }

      const newBadge = document.createElement('span');
      newBadge.className = 'browse-new-badge';
      newBadge.textContent = 'ថ្មី';
      poster.appendChild(newBadge);

      if (item.episodeCount) {
        const badge = document.createElement('span');
        badge.className = 'browse-ep-badge';
        badge.textContent = `${item.episodeCount} ភាគ`;
        poster.appendChild(badge);
      }

      const body = document.createElement('div');
      body.className = 'browse-card-body';

      const title = document.createElement('div');
      title.className = 'browse-card-title';
      title.textContent = item.title;
      body.appendChild(title);

      const metaParts = [];
      if (item.publishAt) metaParts.push(item.publishAt);
      if (item.heat) metaParts.push(item.heat);
      else if (Array.isArray(item.tags) && item.tags[0]) metaParts.push(item.tags[0]);

      if (metaParts.length > 0) {
        const sub = document.createElement('div');
        sub.className = 'browse-card-sub';
        sub.textContent = metaParts.join(' • ');
        body.appendChild(sub);
      }

      card.appendChild(poster);
      card.appendChild(body);

      card.addEventListener('click', () => {
        el.urlInput.value = item.url || item.id;
        loadSeriesFromInput(item.id);
      });

      el.newUpdatesGrid.appendChild(card);
    }

    el.loadMoreNewUpdatesBtn.classList.toggle('hidden', !state.newUpdateHasMore);
  } finally {
    el.newUpdatesLoading.classList.add('hidden');
  }
}

function renderCategories() {
  el.categoryPills.innerHTML = '';
  for (const cat of state.categories) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `cat-pill${cat.id === state.browseCategory ? ' active' : ''}`;
    btn.textContent = cat.nameKm;
    btn.addEventListener('click', () => {
      if (state.browseCategory === cat.id && state.browseItems.length > 0) return;
      loadBrowseCategory(cat.id, 1, false);
    });
    el.categoryPills.appendChild(btn);
  }
}

async function loadBrowseCategory(categoryId, page = 1, append = false) {
  state.browseCategory = categoryId;
  state.browsePage = page;
  renderCategories();

  if (!append) {
    el.browseGrid.innerHTML = '';
    state.browseItems = [];
  }
  el.browseLoading.classList.remove('hidden');
  el.loadMoreBrowseBtn.classList.add('hidden');

  try {
    const res = await window.hongguoAPI.browseCategory(categoryId, page);
    if (!res.ok) {
      showToast(res.error || 'មិនអាចផ្ទុកបញ្ជីរឿងពី hongguoduanju.com បានទេ', 'error');
      return;
    }

    state.browseLoaded = true;
    state.browseHasMore = Boolean(res.data.hasMore);
    const newItems = res.data.items || [];
    state.browseItems.push(...newItems);

    for (const item of newItems) {
      const card = document.createElement('div');
      card.className = 'browse-card';

      const poster = document.createElement('div');
      poster.className = 'browse-poster';

      if (item.cover) {
        const img = document.createElement('img');
        img.src = item.cover;
        img.alt = item.title;
        img.loading = 'lazy';
        poster.appendChild(img);
      }

      if (item.episodeCount) {
        const badge = document.createElement('span');
        badge.className = 'browse-ep-badge';
        badge.textContent = `${item.episodeCount} ភាគ`;
        poster.appendChild(badge);
      }

      const body = document.createElement('div');
      body.className = 'browse-card-body';
      const title = document.createElement('div');
      title.className = 'browse-card-title';
      title.textContent = item.title;
      body.appendChild(title);

      card.appendChild(poster);
      card.appendChild(body);

      card.addEventListener('click', () => {
        el.urlInput.value = item.url || item.id;
        loadSeriesFromInput(item.id);
      });

      el.browseGrid.appendChild(card);
    }

    el.loadMoreBrowseBtn.classList.toggle('hidden', !state.browseHasMore);
  } finally {
    el.browseLoading.classList.add('hidden');
  }
}

/**
 * Aggregates individual episode tasks by seriesId into a single batch summary object
 * for the Downloads tab (1 card per drama batch).
 */
function summarizeSeriesBatch(tasks) {
  if (!Array.isArray(tasks) || tasks.length === 0) return null;

  const sorted = [...tasks].sort((a, b) => (a.episodeNumber || 0) - (b.episodeNumber || 0));
  const totalCount = sorted.length;
  let completedCount = 0;
  let failedCount = 0;
  let cancelledCount = 0;
  let activeCount = 0;
  let progressPoints = 0;
  let totalBytes = 0;
  let latestCompletedFile = null;
  let thumbnailPath = null;
  let definition = null;
  let currentActiveTask = null;
  let latestCreatedAt = 0;

  for (const t of sorted) {
    if (t.createdAt > latestCreatedAt) latestCreatedAt = t.createdAt;
    if (t.thumbnailPath) thumbnailPath = t.thumbnailPath;
    if (t.definition) definition = t.definition;

    if (t.status === 'completed') {
      completedCount += 1;
      progressPoints += 100;
      totalBytes += Number(t.downloadedBytes || t.totalBytes) || 0;
      if (t.filePath) latestCompletedFile = t.filePath;
    } else if (t.status === 'downloading' || t.status === 'resolving') {
      activeCount += 1;
      progressPoints += Math.max(0, Math.min(99, Number(t.percent) || 0));
      totalBytes += Number(t.downloadedBytes) || 0;
      if (!currentActiveTask) currentActiveTask = t;
    } else if (t.status === 'queued') {
      activeCount += 1;
      if (!currentActiveTask) currentActiveTask = t;
    } else if (t.status === 'failed') {
      failedCount += 1;
    } else if (t.status === 'cancelled') {
      cancelledCount += 1;
    }
  }

  const overallPercent =
    completedCount === totalCount
      ? 100
      : totalCount > 0
      ? Math.min(99, Math.round(progressPoints / totalCount))
      : 0;

  let batchStatus = 'queued';
  if (activeCount > 0) {
    batchStatus = 'downloading';
  } else if (completedCount === totalCount) {
    batchStatus = 'completed';
  } else if (failedCount > 0) {
    batchStatus = 'failed';
  } else if (cancelledCount > 0) {
    batchStatus = 'cancelled';
  }

  let statusDetailKm = '';
  if (batchStatus === 'completed') {
    statusDetailKm = `ទាញយករួចរាល់ទាំង ${totalCount} ភាគ ✓`;
  } else if (batchStatus === 'downloading' && currentActiveTask) {
    const epNumStr = String(currentActiveTask.episodeNumber).padStart(3, '0');
    const epPct = currentActiveTask.percent > 0 ? ` (${currentActiveTask.percent}%)` : '';
    statusDetailKm = `កំពុងទាញយក ភាគ ${epNumStr}${epPct}`;
  } else if (batchStatus === 'failed') {
    statusDetailKm = `រួចរាល់ ${completedCount}/${totalCount} ភាគ • បរាជ័យ ${failedCount} ភាគ`;
  } else if (batchStatus === 'cancelled') {
    statusDetailKm = `បានបោះបង់ (${completedCount}/${totalCount} ភាគ)`;
  } else {
    statusDetailKm = `រង់ចាំទាញយក (${totalCount} ភាគ)`;
  }

  const first = sorted[0];
  return {
    seriesId: String(first.seriesId),
    seriesTitle: first.seriesTitle || String(first.seriesId),
    seriesCover: first.seriesCover || '',
    totalCount,
    completedCount,
    failedCount,
    cancelledCount,
    activeCount,
    overallPercent,
    batchStatus,
    statusDetailKm,
    totalBytes,
    definition,
    latestCompletedFile,
    thumbnailPath,
    latestCreatedAt,
  };
}

function buildBatchActionButtons(summary) {
  const frag = document.createDocumentFragment();

  if (summary.latestCompletedFile) {
    const playBtn = document.createElement('button');
    playBtn.type = 'button';
    playBtn.className = 'btn-ghost-sm';
    playBtn.textContent = 'បើកវីដេអូ';
    playBtn.addEventListener('click', () => window.hongguoAPI.openDownloadedFile(summary.latestCompletedFile));
    frag.appendChild(playBtn);
  }

  if (summary.thumbnailPath) {
    const thumbBtn = document.createElement('button');
    thumbBtn.type = 'button';
    thumbBtn.className = 'btn-ghost-sm';
    thumbBtn.textContent = 'បើករូបភាព';
    thumbBtn.addEventListener('click', () => window.hongguoAPI.openDownloadedFile(summary.thumbnailPath));
    frag.appendChild(thumbBtn);
  }

  const folderBtn = document.createElement('button');
  folderBtn.type = 'button';
  folderBtn.className = 'btn-ghost-sm';
  folderBtn.textContent = 'បើកថតឯកសារ';
  folderBtn.addEventListener('click', () =>
    window.hongguoAPI.showInFolder(summary.latestCompletedFile || summary.thumbnailPath || null)
  );
  frag.appendChild(folderBtn);

  if (summary.activeCount > 0) {
    const cancelBtn = document.createElement('button');
    cancelBtn.type = 'button';
    cancelBtn.className = 'btn-ghost-sm';
    cancelBtn.textContent = 'បោះបង់';
    cancelBtn.addEventListener('click', () => window.hongguoAPI.cancelSeriesDownloads(summary.seriesId));
    frag.appendChild(cancelBtn);
  }

  if (summary.failedCount > 0 || summary.cancelledCount > 0) {
    const retryBtn = document.createElement('button');
    retryBtn.type = 'button';
    retryBtn.className = 'btn-ghost-sm';
    retryBtn.textContent = 'ទាញយកម្តងទៀត';
    retryBtn.addEventListener('click', () => window.hongguoAPI.retrySeriesDownloads(summary.seriesId));
    frag.appendChild(retryBtn);
  }

  return frag;
}

/**
 * Renders 1 unified card per drama series batch in the Downloads Queue tab,
 * showing the thumbnail, how many episodes have been downloaded (X / Y ភាគ),
 * current episode status, and overall batch progress.
 */
function renderDownloadQueue() {
  const allTasks = Array.from(state.tasksById.values());
  const activeEpisodeCount = allTasks.filter(
    (t) => t.status === 'queued' || t.status === 'resolving' || t.status === 'downloading'
  ).length;

  el.activeQueueBadge.textContent = String(activeEpisodeCount);
  el.activeQueueBadge.classList.toggle('hidden', activeEpisodeCount === 0);

  const groupedBySeries = new Map();
  for (const task of allTasks) {
    const sid = String(task.seriesId);
    if (!groupedBySeries.has(sid)) groupedBySeries.set(sid, []);
    groupedBySeries.get(sid).push(task);
  }

  const summaries = Array.from(groupedBySeries.values())
    .map(summarizeSeriesBatch)
    .filter(Boolean)
    .sort((a, b) => b.latestCreatedAt - a.latestCreatedAt);

  el.queueEmpty.classList.toggle('hidden', summaries.length > 0);
  el.downloadQueueList.innerHTML = '';

  for (const summary of summaries) {
    const card = document.createElement('div');
    card.className = 'queue-item';

    if (summary.seriesCover) {
      const thumbWrap = document.createElement('div');
      thumbWrap.className = 'queue-thumb-wrap';
      const img = document.createElement('img');
      img.src = summary.seriesCover;
      img.alt = '';
      img.onerror = () => thumbWrap.classList.add('hidden');
      thumbWrap.appendChild(img);
      card.appendChild(thumbWrap);
    }

    const content = document.createElement('div');
    content.className = 'queue-item-content';

    const top = document.createElement('div');
    top.className = 'queue-item-top';

    const left = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'queue-item-title';
    title.textContent = summary.seriesTitle;

    const sub = document.createElement('div');
    sub.className = 'queue-item-sub';
    const subParts = [summary.statusDetailKm];
    if (summary.definition) subParts.push(summary.definition);
    if (summary.totalBytes > 0) subParts.push(formatBytes(summary.totalBytes));
    sub.textContent = subParts.join(' • ');

    left.appendChild(title);
    left.appendChild(sub);

    const badge = document.createElement('span');
    badge.className = `queue-status-badge ${summary.batchStatus}`;
    badge.textContent = `បានទាញយក ${summary.completedCount} / ${summary.totalCount} ភាគ`;

    top.appendChild(left);
    top.appendChild(badge);

    const track = document.createElement('div');
    track.className = 'progress-track';
    const fill = document.createElement('div');
    fill.className = `progress-fill${summary.batchStatus === 'completed' ? ' completed' : ''}`;
    fill.style.width = `${summary.overallPercent}%`;
    track.appendChild(fill);

    const bottom = document.createElement('div');
    bottom.className = 'queue-item-bottom';

    const pctLabel = document.createElement('span');
    pctLabel.className = 'queue-item-sub';
    pctLabel.textContent = `${summary.overallPercent}%`;

    const actions = document.createElement('div');
    actions.className = 'queue-item-actions';
    actions.appendChild(buildBatchActionButtons(summary));

    bottom.appendChild(pctLabel);
    bottom.appendChild(actions);

    content.appendChild(top);
    content.appendChild(track);
    content.appendChild(bottom);

    card.appendChild(content);
    el.downloadQueueList.appendChild(card);
  }
}

function showUpdateModal(info, openPopup = true) {
  if (!info || !info.version) return;
  state.pendingUpdate = info;
  const verTransition = `v${info.currentVersion || '1.0.0'} ➔ v${info.version}`;
  const sizeText = info.fileSize ? ` (${formatBytes(info.fileSize)})` : '';
  const notesText =
    info.releaseNotes || 'មានកំណែអាប់ដេតថ្មីសម្រាប់កម្មវិធី ហុងហ្គោ ដោនឡូត!';

  // 1. Show prominent New Version Banner & Titlebar Pill directly on Main UI
  if (el.titlebarUpdateBtn) {
    el.titlebarUpdateBtn.innerHTML = `<span>អាប់ដេត v${info.version} ⬆</span>`;
    el.titlebarUpdateBtn.classList.remove('hidden');
  }
  if (el.mainUpdateBanner) {
    el.mainUpdateBanner.classList.remove('hidden');
  }
  if (el.mainUpdateBadge) {
    el.mainUpdateBadge.textContent = verTransition;
  }
  if (el.mainUpdateNotes) {
    el.mainUpdateNotes.textContent = `${notesText}${sizeText}`;
  }
  if (el.mainUpdateProgressWrap) {
    el.mainUpdateProgressWrap.classList.add('hidden');
    el.mainUpdateProgressFill.style.width = '0%';
    el.mainUpdateProgressText.textContent = '0%';
  }
  if (el.mainInstallUpdateBtn) {
    el.mainInstallUpdateBtn.disabled = false;
    el.mainInstallUpdateBtn.textContent = `អាប់ដេត v${info.version} ⬆`;
  }

  // 2. Populate & optionally open the Update Modal
  el.updateVersionBadge.textContent = verTransition;
  el.updateFileMeta.textContent = `ឯកសារថ្មី៖ ${info.fileName || ''}${sizeText}`;
  el.updateReleaseNotes.textContent = notesText;
  el.updateProgressWrap.classList.add('hidden');
  el.updateProgressFill.style.width = '0%';
  el.updateProgressText.textContent = '0%';
  el.installUpdateBtn.disabled = false;
  el.installUpdateBtn.textContent = 'អាប់ដេតឥឡូវនេះ';
  if (openPopup) {
    el.updateModal.classList.remove('hidden');
  }
}

async function triggerInstallUpdate() {
  el.installUpdateBtn.disabled = true;
  el.installUpdateBtn.textContent = 'កំពុងដំឡើង...';
  el.updateProgressWrap.classList.remove('hidden');

  if (el.mainInstallUpdateBtn) {
    el.mainInstallUpdateBtn.disabled = true;
    el.mainInstallUpdateBtn.textContent = 'កំពុងទាញយក...';
  }
  if (el.mainUpdateProgressWrap) {
    el.mainUpdateProgressWrap.classList.remove('hidden');
  }

  const res = await window.hongguoAPI.installUpdate();
  if (!res.ok) {
    el.installUpdateBtn.disabled = false;
    el.installUpdateBtn.textContent = 'អាប់ដេតឥឡូវនេះ';
    if (el.mainInstallUpdateBtn) {
      el.mainInstallUpdateBtn.disabled = false;
      el.mainInstallUpdateBtn.textContent = 'អាប់ដេតឥឡូវនេះ ⬆';
    }
    showToast(res.error || 'មិនអាចដំឡើងកំណែអាប់ដេតបានទេ', 'error');
    return;
  }

  el.updateProgressFill.style.width = '100%';
  el.updateProgressText.textContent = '100%';
  if (el.mainUpdateProgressFill) el.mainUpdateProgressFill.style.width = '100%';
  if (el.mainUpdateProgressText) el.mainUpdateProgressText.textContent = '100%';
  if (el.mainInstallUpdateBtn) el.mainInstallUpdateBtn.textContent = 'រួចរាល់ ✓';

  showToast('បានទាញយក និងដំឡើងកំណែថ្មីរួចរាល់!', 'success');
  setTimeout(() => el.updateModal.classList.add('hidden'), 1200);
}

function applySettingsToUi(s) {
  state.settings = { ...state.settings, ...s };
  el.outputDirDisplay.textContent = state.settings.outputDir;
  el.outputDirDisplay.title = state.settings.outputDir;
  el.concurrencySelect.value = String(state.settings.concurrency || 3);
  if (state.settings.quality) {
    el.qualitySelect.value = state.settings.quality;
  }
}

function applyLicenseStatus(statusData) {
  if (!statusData) return;
  if (el.gateMachineId && statusData.machineId) {
    el.gateMachineId.textContent = statusData.machineId;
  }

  if (statusData.licensed && statusData.license) {
    const lic = statusData.license;
    if (el.licenseGateModal) {
      el.licenseGateModal.classList.add('hidden');
    }
    if (el.licenseErrorText) {
      el.licenseErrorText.classList.add('hidden');
      el.licenseErrorText.textContent = '';
    }
    const expDate = lic.expiresAt ? String(lic.expiresAt).slice(0, 10) : '-';
    if (el.licenseHeaderBadge) {
      el.licenseHeaderBadge.textContent = `អាជ្ញាប័ណ្ណ៖ ${lic.planLabelKm} • នៅសល់ ${lic.remainingDays} ថ្ងៃ (ផុតកំណត់ ${expDate})`;
    }
    if (el.licensePlanInfoText) {
      el.licensePlanInfoText.textContent = `កូដ៖ ${lic.keyCode} (${lic.planLabelKm}) • ផុតកំណត់៖ ${expDate} (នៅសល់ ${lic.remainingDays} ថ្ងៃ)`;
      el.licensePlanInfoText.title = `PC ID: ${lic.boundMachineId || statusData.machineId}`;
    }
  } else {
    if (el.licenseGateModal) {
      el.licenseGateModal.classList.remove('hidden');
    }
    if (el.licenseHeaderBadge) {
      el.licenseHeaderBadge.textContent = 'សូមបញ្ចូលកូដអាជ្ញាប័ណ្ណដើម្បីប្រើប្រាស់កម្មវិធី (1 PC = 1 Key)';
    }
    if (el.licensePlanInfoText) {
      el.licensePlanInfoText.textContent = `មិនទាន់មានអាជ្ញាប័ណ្ណ • PC ID: ${statusData.machineId || ''}`;
    }
    if (el.licenseErrorText) {
      if (statusData.error) {
        el.licenseErrorText.textContent = statusData.error;
        el.licenseErrorText.classList.remove('hidden');
      } else {
        el.licenseErrorText.classList.add('hidden');
      }
    }
  }
}

async function refreshLicenseStatus() {
  try {
    const res = await window.hongguoAPI.getLicenseStatus();
    if (res && res.ok && res.data) {
      applyLicenseStatus(res.data);
      return res.data;
    }
  } catch {
    // Ignore transient IPC error
  }
  return null;
}

async function handleActivateLicense() {
  if (!el.licenseKeyInput) return;
  const keyCode = el.licenseKeyInput.value.trim();
  if (!keyCode) {
    if (el.licenseErrorText) {
      el.licenseErrorText.textContent = 'សូមបញ្ចូលកូដអាជ្ញាប័ណ្ណជាមុនសិន!';
      el.licenseErrorText.classList.remove('hidden');
    }
    return;
  }

  el.activateLicenseBtn.disabled = true;
  el.activateLicenseBtn.textContent = 'កំពុងផ្ទៀងផ្ទាត់កូដ...';
  if (el.licenseErrorText) el.licenseErrorText.classList.add('hidden');

  try {
    const res = await window.hongguoAPI.activateLicense(keyCode);
    if (!res.ok) {
      if (el.licenseErrorText) {
        el.licenseErrorText.textContent = res.error || 'កូដអាជ្ញាប័ណ្ណមិនត្រឹមត្រូវ ឬផុតកំណត់!';
        el.licenseErrorText.classList.remove('hidden');
      }
      return;
    }

    el.licenseKeyInput.value = '';
    await refreshLicenseStatus();
    showToast('បានចូលប្រើប្រាស់អាជ្ញាប័ណ្ណដោយជោគជ័យ!', 'success');
  } finally {
    el.activateLicenseBtn.disabled = false;
    el.activateLicenseBtn.textContent = 'ផ្ទៀងផ្ទាត់ & ចូលប្រើកម្មវិធី (Activate)';
  }
}

function bindEvents() {
  el.minBtn.addEventListener('click', () => window.hongguoAPI.minimizeWindow());
  el.closeBtn.addEventListener('click', () => window.hongguoAPI.closeWindow());
  el.pinBtn.addEventListener('click', async () => {
    const pinned = await window.hongguoAPI.toggleAlwaysOnTop();
    el.pinBtn.classList.toggle('active', Boolean(pinned));
  });

  for (const btn of el.tabButtons) {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  }

  if (el.goNewUpdatesBtn) {
    el.goNewUpdatesBtn.addEventListener('click', () => switchTab('new-updates'));
  }
  el.goBrowseBtn.addEventListener('click', () => switchTab('browse'));

  if (el.refreshNewUpdatesBtn) {
    el.refreshNewUpdatesBtn.addEventListener('click', () => {
      loadNewUpdates(state.newUpdateType, '', false);
    });
  }

  if (el.loadMoreNewUpdatesBtn) {
    el.loadMoreNewUpdatesBtn.addEventListener('click', () => {
      if (state.newUpdateHasMore && state.newUpdateCursor) {
        loadNewUpdates(state.newUpdateType, state.newUpdateCursor, true);
      }
    });
  }

  el.pasteBtn.addEventListener('click', async () => {
    const text = await window.hongguoAPI.readClipboard();
    if (text) {
      el.urlInput.value = text.trim();
      el.urlInput.focus();
    }
  });

  el.fetchBtn.addEventListener('click', () => loadSeriesFromInput());
  el.urlInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') loadSeriesFromInput();
  });

  el.seriesSourceLink.addEventListener('click', () => {
    if (state.series && state.series.sourceUrl) {
      window.hongguoAPI.openExternalHongguo(state.series.sourceUrl);
    }
  });

  el.selectAllBtn.addEventListener('click', () => {
    if (!state.series) return;
    for (const ep of state.series.episodes) {
      state.selectedEpisodes.add(String(ep.id));
    }
    renderEpisodesGrid();
    updateSelectedButton();
  });

  el.clearSelectBtn.addEventListener('click', () => {
    state.selectedEpisodes.clear();
    renderEpisodesGrid();
    updateSelectedButton();
  });

  el.applyRangeBtn.addEventListener('click', () => {
    if (!state.series) return;
    const total = state.series.episodes.length;
    let start = Math.max(1, Number(el.rangeStartInput.value) || 1);
    let end = Math.min(total, Number(el.rangeEndInput.value) || total);
    if (end < start) [start, end] = [end, start];

    state.selectedEpisodes.clear();
    for (const ep of state.series.episodes) {
      if (ep.number >= start && ep.number <= end) {
        state.selectedEpisodes.add(String(ep.id));
      }
    }
    renderEpisodesGrid();
    updateSelectedButton();
  });

  el.downloadSelectedBtn.addEventListener('click', async () => {
    if (!state.series) return;
    const selected = state.series.episodes.filter((ep) => state.selectedEpisodes.has(String(ep.id)));
    await enqueueEpisodeList(selected);
  });

  el.qualitySelect.addEventListener('change', async () => {
    const res = await window.hongguoAPI.updateSettings({ quality: el.qualitySelect.value });
    if (res.ok) applySettingsToUi(res.data);
  });

  el.loadMoreBrowseBtn.addEventListener('click', () => {
    if (state.browseHasMore) {
      loadBrowseCategory(state.browseCategory, state.browsePage + 1, true);
    }
  });

  el.openOutputFolderBtn.addEventListener('click', () => {
    window.hongguoAPI.showInFolder(null);
  });

  el.clearFinishedBtn.addEventListener('click', async () => {
    const res = await window.hongguoAPI.clearFinishedDownloads();
    if (res.ok) {
      state.tasksById.clear();
      for (const task of res.data) {
        state.tasksById.set(task.taskId, task);
      }
      renderDownloadQueue();
    }
  });

  el.chooseDirBtn.addEventListener('click', async () => {
    const res = await window.hongguoAPI.chooseOutputDir();
    if (res.ok && !res.canceled) {
      applySettingsToUi(res.data);
      showToast('បានផ្លាស់ប្តូរទីតាំងរក្សាទុករួចរាល់!', 'success');
    }
  });

  el.concurrencySelect.addEventListener('change', async () => {
    const res = await window.hongguoAPI.updateSettings({
      concurrency: Number(el.concurrencySelect.value) || 3,
    });
    if (res.ok) applySettingsToUi(res.data);
  });

  el.manualCheckUpdateBtn.addEventListener('click', async () => {
    el.manualCheckUpdateBtn.disabled = true;
    el.manualUpdateStatus.classList.add('hidden');
    try {
      const res = await window.hongguoAPI.checkForUpdates();
      if (res.ok && res.data && res.data.updateAvailable && res.data.update) {
        showUpdateModal(res.data.update);
      } else {
        el.manualUpdateStatus.textContent =
          'មិនមានឯកសារអាប់ដេតថ្មីទេ — កម្មវិធីរបស់អ្នកគឺជាកំណែចុងក្រោយបំផុតហើយ។';
        el.manualUpdateStatus.classList.remove('hidden');
      }
    } finally {
      el.manualCheckUpdateBtn.disabled = false;
    }
  });

  el.remindLaterBtn.addEventListener('click', () => {
    el.updateModal.classList.add('hidden');
  });

  el.installUpdateBtn.addEventListener('click', () => {
    triggerInstallUpdate();
  });

  if (el.mainInstallUpdateBtn) {
    el.mainInstallUpdateBtn.addEventListener('click', () => {
      triggerInstallUpdate();
    });
  }

  if (el.titlebarUpdateBtn) {
    el.titlebarUpdateBtn.addEventListener('click', () => {
      if (state.pendingUpdate) {
        showUpdateModal(state.pendingUpdate, true);
      }
    });
  }

  if (el.copyMachineIdBtn) {
    el.copyMachineIdBtn.addEventListener('click', async () => {
      const idText = el.gateMachineId ? el.gateMachineId.textContent.trim() : '';
      if (idText) {
        await window.hongguoAPI.writeClipboard(idText);
        showToast(`បានចម្លង PC ID: ${idText}`, 'success');
      }
    });
  }

  if (el.pasteLicenseKeyBtn) {
    el.pasteLicenseKeyBtn.addEventListener('click', async () => {
      const text = await window.hongguoAPI.readClipboard();
      if (text && el.licenseKeyInput) {
        el.licenseKeyInput.value = text.trim().toUpperCase();
        el.licenseKeyInput.focus();
      }
    });
  }

  if (el.activateLicenseBtn) {
    el.activateLicenseBtn.addEventListener('click', () => handleActivateLicense());
  }

  if (el.licenseKeyInput) {
    el.licenseKeyInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') handleActivateLicense();
    });
  }

  if (el.logoutLicenseBtn) {
    el.logoutLicenseBtn.addEventListener('click', async () => {
      await window.hongguoAPI.logoutLicense();
      await refreshLicenseStatus();
      showToast('បានចាកចេញពីកូដអាជ្ញាប័ណ្ណនៅលើកុំព្យូទ័រនេះ', 'info');
    });
  }

  window.hongguoAPI.onDownloadProgress((task) => {
    if (!task || !task.taskId) return;
    state.tasksById.set(task.taskId, task);
    state.latestTaskByEpisodeId.set(String(task.episodeId), task);
    updateEpisodePillProgress(task);
    renderDownloadQueue();
  });

  window.hongguoAPI.onUpdateAvailable((info) => {
    showUpdateModal(info, true);
  });

  window.hongguoAPI.onUpdateProgress((prog) => {
    const pct = Math.max(0, Math.min(100, Number(prog && prog.percent) || 0));
    el.updateProgressWrap.classList.remove('hidden');
    el.updateProgressFill.style.width = `${pct}%`;
    el.updateProgressText.textContent = `${pct}%`;

    if (el.mainUpdateProgressWrap) {
      el.mainUpdateProgressWrap.classList.remove('hidden');
      el.mainUpdateProgressFill.style.width = `${pct}%`;
      el.mainUpdateProgressText.textContent = `${pct}%`;
    }
  });
}

async function init() {
  bindEvents();

  await refreshLicenseStatus();
  setInterval(() => {
    refreshLicenseStatus();
  }, 15000);

  const [catRes, newTypesRes, setRes, dlRes, updRes] = await Promise.all([
    window.hongguoAPI.getCategories(),
    window.hongguoAPI.getNewUpdateTypes(),
    window.hongguoAPI.getSettings(),
    window.hongguoAPI.listDownloads(),
    window.hongguoAPI.getUpdaterInfo(),
  ]);

  if (catRes.ok) {
    state.categories = catRes.data || [];
    renderCategories();
  }
  if (newTypesRes && newTypesRes.ok) {
    state.newUpdateTypes = newTypesRes.data || [];
    renderNewUpdateTypes();
  }
  if (setRes.ok) {
    applySettingsToUi(setRes.data);
  }
  if (dlRes.ok && Array.isArray(dlRes.data)) {
    for (const task of dlRes.data) {
      state.tasksById.set(task.taskId, task);
      state.latestTaskByEpisodeId.set(String(task.episodeId), task);
    }
    renderDownloadQueue();
  }
  if (updRes.ok && updRes.data) {
    el.appVersionText.textContent = `កំណែបច្ចុប្បន្ន v${updRes.data.currentVersion || '1.0.0'}`;
    if (updRes.data.pendingUpdate) {
      showUpdateModal(updRes.data.pendingUpdate, false);
    }
  }
}

init();
