const EventEmitter = require('node:events');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');

const UPDATE_EXTENSIONS = new Set(['.exe', '.msi', '.zip', '.nupkg']);
const FILENAME_SEMVER_RE = /(?:^|[-_v])(\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?)(?=\.(?:exe|msi|zip|nupkg)$)/i;

function normalizeVersion(v) {
  return String(v || '')
    .trim()
    .replace(/^v/i, '');
}

/**
 * Compares two semver strings (e.g. "1.10.0" vs "1.2.0").
 * Returns 1 if a > b, -1 if a < b, 0 if equal.
 */
function compareVersions(a, b) {
  const cleanA = normalizeVersion(a);
  const cleanB = normalizeVersion(b);
  if (!cleanA || !cleanB) return 0;

  const [mainA, preA = ''] = cleanA.split('-', 2);
  const [mainB, preB = ''] = cleanB.split('-', 2);
  const partsA = mainA.split('.').map((n) => parseInt(n, 10) || 0);
  const partsB = mainB.split('.').map((n) => parseInt(n, 10) || 0);
  const maxLen = Math.max(partsA.length, partsB.length, 3);

  for (let i = 0; i < maxLen; i += 1) {
    const x = partsA[i] || 0;
    const y = partsB[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }

  if (!preA && preB) return 1;
  if (preA && !preB) return -1;
  if (preA && preB) {
    if (preA > preB) return 1;
    if (preA < preB) return -1;
  }
  return 0;
}

function parseSimpleYaml(text) {
  const result = {};
  for (const rawLine of String(text || '').split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const colonIdx = line.indexOf(':');
    if (colonIdx <= 0) continue;
    const key = line.slice(0, colonIdx).trim();
    const val = line.slice(colonIdx + 1).trim().replace(/^['"]|['"]$/g, '');
    if (key && val) result[key] = val;
  }
  return result;
}

class UpdaterService extends EventEmitter {
  constructor(options = {}) {
    super();
    this.currentVersion = normalizeVersion(options.currentVersion || '1.0.0');
    this.updateDirs = Array.isArray(options.updateDirs) ? options.updateDirs.filter(Boolean) : [];
    this.stagingDir = options.stagingDir || null;
    this.feedUrl = options.feedUrl || process.env.HONGGUO_UPDATE_URL || '';
    this.githubRepo = String(options.githubRepo || '').trim();
    this.appRootDir = options.appRootDir || null;
    this.appUpdateConfigPath = options.appUpdateConfigPath || null;
    this.openFileFn = options.openFileFn || null;
    this.relaunchAppFn = options.relaunchAppFn || null;
    this.enableElectronUpdater = options.enableElectronUpdater !== false;

    this._watchers = [];
    this._watchTimer = null;
    this._checking = false;
    this._pendingUpdate = null;
    this._lastNotifiedKey = null;
    this._autoUpdater = null;
    this._autoUpdaterReady = false;
  }

  _initElectronUpdater() {
    if (!this.enableElectronUpdater || this._autoUpdaterReady) return;
    this._autoUpdaterReady = true;

    const hasRemoteConfig =
      Boolean(this.feedUrl) ||
      (this.appUpdateConfigPath && fs.existsSync(this.appUpdateConfigPath));
    if (!hasRemoteConfig) return;

    try {
      const { autoUpdater } = require('electron-updater');
      autoUpdater.autoDownload = false;
      autoUpdater.autoInstallOnAppQuit = true;
      if (this.feedUrl) {
        autoUpdater.setFeedURL({ provider: 'generic', url: this.feedUrl });
      }

      autoUpdater.on('update-available', (info) => {
        const version = normalizeVersion(info && info.version);
        if (!version || compareVersions(version, this.currentVersion) <= 0) return;

        const fileEntry = Array.isArray(info.files) && info.files[0] ? info.files[0] : {};
        const payload = {
          source: 'electron-updater',
          version,
          currentVersion: this.currentVersion,
          fileName: fileEntry.url || info.path || `HongguoDownloader-Setup-${version}.exe`,
          filePath: null,
          fileSize: Number(fileEntry.size) || 0,
          releaseNotes:
            typeof info.releaseNotes === 'string'
              ? info.releaseNotes
              : 'មានកំណែអាប់ដេតថ្មីសម្រាប់កម្មវិធី Hongguo Downloader!',
          releaseDate: info.releaseDate || new Date().toISOString(),
        };
        this._setPendingUpdate(payload, true);
      });

      autoUpdater.on('download-progress', (prog) => {
        this.emit('download-progress', {
          percent: Math.round(Number(prog.percent) || 0),
          transferredBytes: Number(prog.transferred) || 0,
          totalBytes: Number(prog.total) || 0,
        });
      });

      autoUpdater.on('error', () => {
        // Silent failure: do not bother user with popup if update check fails
      });

      this._autoUpdater = autoUpdater;
    } catch {
      this._autoUpdater = null;
    }
  }

  _setPendingUpdate(payload, emitPopup) {
    this._pendingUpdate = payload;
    const key = `${payload.version}:${payload.filePath || payload.fileName}`;
    if (emitPopup && this._lastNotifiedKey !== key) {
      this._lastNotifiedKey = key;
      this.emit('update-available', payload);
    }
  }

  async _scanUpdateDirectory(dirPath) {
    let entries;
    try {
      entries = await fsp.readdir(dirPath, { withFileTypes: true });
    } catch {
      return null;
    }

    const candidates = [];

    // 1. Check update.json manifest paired with an actual update file
    const updateJsonPath = path.join(dirPath, 'update.json');
    try {
      const raw = await fsp.readFile(updateJsonPath, 'utf8');
      const meta = JSON.parse(raw);
      const version = normalizeVersion(meta.version);
      const targetFile = meta.file || meta.fileName || meta.path;
      if (version && targetFile && compareVersions(version, this.currentVersion) > 0) {
        const resolvedFile = path.resolve(dirPath, path.basename(String(targetFile)));
        const stat = await fsp.stat(resolvedFile).catch(() => null);
        if (stat && stat.isFile()) {
          candidates.push({
            source: 'local-file',
            version,
            currentVersion: this.currentVersion,
            fileName: path.basename(resolvedFile),
            filePath: resolvedFile,
            fileSize: stat.size,
            releaseNotes:
              meta.releaseNotes ||
              meta.notes ||
              'មានឯកសារអាប់ដេតថ្មីសម្រាប់កម្មវិធី ហុងហ្គោ ដោនឡូត!',
            releaseDate: meta.releaseDate || stat.mtime.toISOString(),
          });
        }
      }
    } catch {
      // No valid update.json
    }

    // 2. Check latest.yml manifest paired with an actual update file
    const latestYmlPath = path.join(dirPath, 'latest.yml');
    try {
      const rawYml = await fsp.readFile(latestYmlPath, 'utf8');
      const meta = parseSimpleYaml(rawYml);
      const version = normalizeVersion(meta.version);
      const targetFile = meta.path || meta.url;
      if (version && targetFile && compareVersions(version, this.currentVersion) > 0) {
        const resolvedFile = path.resolve(dirPath, path.basename(String(targetFile)));
        const stat = await fsp.stat(resolvedFile).catch(() => null);
        if (stat && stat.isFile()) {
          candidates.push({
            source: 'local-file',
            version,
            currentVersion: this.currentVersion,
            fileName: path.basename(resolvedFile),
            filePath: resolvedFile,
            fileSize: stat.size,
            releaseNotes: 'មានកំណែអាប់ដេតថ្មី (latest.yml) រួចរាល់សម្រាប់ដំឡើង!',
            releaseDate: meta.releaseDate || stat.mtime.toISOString(),
          });
        }
      }
    } catch {
      // No valid latest.yml
    }

    // 3. Check standalone versioned installer files (.exe, .msi, .zip, .nupkg)
    for (const entry of entries) {
      if (!entry.isFile()) continue;
      const ext = path.extname(entry.name).toLowerCase();
      if (!UPDATE_EXTENSIONS.has(ext)) continue;

      const match = FILENAME_SEMVER_RE.exec(entry.name);
      if (!match) continue;

      const version = normalizeVersion(match[1]);
      if (compareVersions(version, this.currentVersion) <= 0) continue;

      const fullPath = path.join(dirPath, entry.name);
      const stat = await fsp.stat(fullPath).catch(() => null);
      if (!stat || !stat.isFile()) continue;

      candidates.push({
        source: 'local-file',
        version,
        currentVersion: this.currentVersion,
        fileName: entry.name,
        filePath: fullPath,
        fileSize: stat.size,
        releaseNotes: `រកឃើញឯកសារអាប់ដេតថ្មី ${entry.name} (កំណែ v${version})`,
        releaseDate: stat.mtime.toISOString(),
      });
    }

    if (candidates.length === 0) return null;
    candidates.sort((a, b) => compareVersions(b.version, a.version));
    return candidates[0];
  }

  /**
   * Checks a remote online update feed URL (either a direct update.json URL,
   * a directory URL containing update.json, or a GitHub Releases API latest URL).
   */
  async _checkRemoteJsonFeed() {
    const rawUrl = String(this.feedUrl || '').trim();
    const endpoints = [];

    if (rawUrl && /^https?:\/\//i.test(rawUrl)) {
      if (rawUrl.endsWith('.json') || rawUrl.includes('api.github.com/repos/')) {
        endpoints.push(rawUrl);
      } else {
        endpoints.push(`${rawUrl.replace(/\/+$/, '')}/update.json`);
        endpoints.push(rawUrl);
      }
    }

    if (this.githubRepo) {
      endpoints.push(`https://raw.githubusercontent.com/${this.githubRepo}/main/update.json`);
      endpoints.push(`https://raw.githubusercontent.com/${this.githubRepo}/master/update.json`);
      endpoints.push(`https://api.github.com/repos/${this.githubRepo}/releases/latest`);
    }

    const uniqueEndpoints = Array.from(new Set(endpoints));
    if (uniqueEndpoints.length === 0) return null;

    for (const url of uniqueEndpoints) {
      try {
        const res = await fetch(url, {
          headers: {
            Accept: 'application/json',
            'User-Agent': 'Hongguo-Downloader-Updater/1.0',
          },
        });
        if (!res.ok) continue;
        const data = await res.json();
        if (!data || typeof data !== 'object') continue;

        // Support GitHub Releases API (/repos/:owner/:repo/releases/latest)
        const rawVer = data.version || data.tag_name || '';
        const version = normalizeVersion(rawVer);
        if (!version || compareVersions(version, this.currentVersion) <= 0) {
          continue;
        }

        let downloadUrl = data.url || data.downloadUrl || data.file || '';
        let fileName = data.fileName || '';
        let fileSize = Number(data.size || data.fileSize) || 0;

        if (!downloadUrl && Array.isArray(data.assets) && data.assets.length > 0) {
          const winAsset =
            data.assets.find((a) => /\.(exe|msi|zip)$/i.test(a.name || '')) || data.assets[0];
          if (winAsset && winAsset.browser_download_url) {
            downloadUrl = winAsset.browser_download_url;
            fileName = winAsset.name || '';
            fileSize = Number(winAsset.size) || 0;
          }
        }

        if (!downloadUrl) continue;
        if (!/^https?:\/\//i.test(downloadUrl)) {
          const base = url.replace(/\/[^/]*$/, '');
          downloadUrl = `${base}/${downloadUrl.replace(/^\/+/, '')}`;
        }

        if (!fileName) {
          try {
            const parsedUrl = new URL(downloadUrl);
            fileName = path.basename(parsedUrl.pathname) || `HongguoDownloader-Setup-${version}.exe`;
          } catch {
            fileName = `HongguoDownloader-Setup-${version}.exe`;
          }
        }

        return {
          source: 'remote-url',
          version,
          currentVersion: this.currentVersion,
          fileName,
          filePath: null,
          downloadUrl,
          fileSize,
          releaseNotes:
            data.releaseNotes ||
            data.notes ||
            data.body ||
            `មានកំណែអាប់ដេតអនឡាញថ្មី v${version} សម្រាប់កម្មវិធី ហុងហ្គោ ដោនឡូត!`,
          releaseDate: data.releaseDate || data.published_at || new Date().toISOString(),
        };
      } catch {
        // Ignore network/JSON error and continue
      }
    }

    return null;
  }

  /**
   * Checks local update folders, online JSON/GitHub feed, and optional electron-updater feed.
   * Emits 'update-available' ONLY when an actual new update (version > currentVersion) is found.
   */
  async checkForUpdates(options = {}) {
    const forceEmit = Boolean(options.forceEmit);
    if (this._checking) {
      return this._pendingUpdate
        ? { updateAvailable: true, update: this._pendingUpdate }
        : { updateAvailable: false, update: null };
    }

    this._checking = true;
    try {
      const localMatches = [];
      for (const dir of this.updateDirs) {
        const found = await this._scanUpdateDirectory(dir);
        if (found) localMatches.push(found);
      }

      if (localMatches.length > 0) {
        localMatches.sort((a, b) => compareVersions(b.version, a.version));
        const best = localMatches[0];
        if (forceEmit) this._lastNotifiedKey = null;
        this._setPendingUpdate(best, true);
        return { updateAvailable: true, update: best };
      }

      // Check Online JSON / GitHub Releases Feed
      const remoteMatch = await this._checkRemoteJsonFeed();
      if (remoteMatch) {
        if (forceEmit) this._lastNotifiedKey = null;
        this._setPendingUpdate(remoteMatch, true);
        return { updateAvailable: true, update: remoteMatch };
      }

      this._initElectronUpdater();
      if (this._autoUpdater) {
        try {
          const checkRes = await this._autoUpdater.checkForUpdates();
          const info = checkRes && checkRes.updateInfo;
          const version = normalizeVersion(info && info.version);
          if (version && compareVersions(version, this.currentVersion) > 0 && this._pendingUpdate) {
            return { updateAvailable: true, update: this._pendingUpdate };
          }
        } catch {
          // Silent: no update popup on network/feed absence
        }
      }

      this._pendingUpdate = null;
      return { updateAvailable: false, update: null };
    } finally {
      this._checking = false;
    }
  }

  startWatching() {
    this.stopWatching();
    for (const dir of this.updateDirs) {
      try {
        fs.mkdirSync(dir, { recursive: true });
        const watcher = fs.watch(dir, () => {
          if (this._watchTimer) clearTimeout(this._watchTimer);
          this._watchTimer = setTimeout(() => {
            this.checkForUpdates().catch(() => {});
          }, 500);
        });
        watcher.on('error', () => {});
        this._watchers.push(watcher);
      } catch {
        // Ignore non-watchable paths
      }
    }
  }

  stopWatching() {
    if (this._watchTimer) {
      clearTimeout(this._watchTimer);
      this._watchTimer = null;
    }
    for (const w of this._watchers) {
      try {
        w.close();
      } catch {
        // Ignore close error
      }
    }
    this._watchers = [];
  }

  async _copyFileWithProgress(srcPath, destPath) {
    const stat = await fsp.stat(srcPath);
    const totalBytes = stat.size;
    await fsp.mkdir(path.dirname(destPath), { recursive: true });

    await new Promise((resolve, reject) => {
      const reader = fs.createReadStream(srcPath);
      const writer = fs.createWriteStream(destPath);
      let transferredBytes = 0;

      reader.on('data', (chunk) => {
        transferredBytes += chunk.length;
        const percent = totalBytes > 0 ? Math.min(100, Math.round((transferredBytes / totalBytes) * 100)) : 100;
        this.emit('download-progress', { percent, transferredBytes, totalBytes });
      });

      reader.on('error', reject);
      writer.on('error', reject);
      writer.on('finish', resolve);
      reader.pipe(writer);
    });

    this.emit('download-progress', {
      percent: 100,
      transferredBytes: totalBytes,
      totalBytes,
    });
  }

  async _downloadRemoteFileWithProgress(downloadUrl, destPath, fallbackSize = 0) {
    await fsp.mkdir(path.dirname(destPath), { recursive: true });
    const res = await fetch(downloadUrl, {
      headers: {
        'User-Agent': 'Hongguo-Downloader-Updater/1.0',
      },
    });
    if (!res.ok || !res.body) {
      throw new Error(`មិនអាចទាញយកឯកសារអាប់ដេតពីអនឡាញបានទេ (HTTP ${res.status})`);
    }

    const totalBytes = Number(res.headers.get('content-length')) || Number(fallbackSize) || 0;
    const writer = fs.createWriteStream(destPath);
    let transferredBytes = 0;

    for await (const chunk of res.body) {
      const buf = Buffer.from(chunk);
      transferredBytes += buf.length;
      if (!writer.write(buf)) {
        await new Promise((resolve) => writer.once('drain', resolve));
      }
      const percent =
        totalBytes > 0 ? Math.min(99, Math.round((transferredBytes / totalBytes) * 100)) : 50;
      this.emit('download-progress', { percent, transferredBytes, totalBytes });
    }

    await new Promise((resolve, reject) => {
      writer.end();
      writer.on('finish', resolve);
      writer.on('error', reject);
    });

    this.emit('download-progress', {
      percent: 100,
      transferredBytes,
      totalBytes: totalBytes || transferredBytes,
    });
  }

  _applyInPlaceAppZip(zipPath) {
    if (!this.appRootDir || !fs.existsSync(this.appRootDir)) return false;
    const { execFileSync } = require('node:child_process');
    try {
      execFileSync('tar.exe', ['-xf', zipPath, '-C', this.appRootDir], { windowsHide: true });
      return true;
    } catch {
      try {
        execFileSync(
          'powershell.exe',
          [
            '-NoProfile',
            '-Command',
            `Expand-Archive -Path "${zipPath}" -DestinationPath "${this.appRootDir}" -Force`,
          ],
          { windowsHide: true }
        );
        return true;
      } catch {
        return false;
      }
    }
  }

  async downloadAndInstallUpdate() {
    if (!this._pendingUpdate) {
      throw new Error('មិនមានឯកសារអាប់ដេតថ្មីសម្រាប់ដំឡើងទេ');
    }

    if (this._pendingUpdate.source === 'electron-updater' && this._autoUpdater) {
      await this._autoUpdater.downloadUpdate();
      this._autoUpdater.quitAndInstall();
      return { started: true, source: 'electron-updater' };
    }

    if (this._pendingUpdate.source === 'remote-url' && this._pendingUpdate.downloadUrl) {
      const targetDir = this.stagingDir || path.join(process.cwd(), 'updates', '.staged');
      const stagedPath = path.join(targetDir, this._pendingUpdate.fileName);
      await this._downloadRemoteFileWithProgress(
        this._pendingUpdate.downloadUrl,
        stagedPath,
        this._pendingUpdate.fileSize
      );

      if (/App-Update.*\.zip$/i.test(this._pendingUpdate.fileName) && this._applyInPlaceAppZip(stagedPath)) {
        if (this.relaunchAppFn) {
          setTimeout(() => this.relaunchAppFn(), 600);
        }
        return {
          started: true,
          source: 'remote-url',
          filePath: stagedPath,
          version: this._pendingUpdate.version,
        };
      }

      if (this.openFileFn) {
        const openErr = await this.openFileFn(stagedPath);
        if (openErr) {
          throw new Error(openErr);
        }
      }

      return {
        started: true,
        source: 'remote-url',
        filePath: stagedPath,
        version: this._pendingUpdate.version,
      };
    }

    const srcPath = this._pendingUpdate.filePath;
    if (!srcPath || !fs.existsSync(srcPath)) {
      throw new Error('រកមិនឃើញឯកសារអាប់ដេតនៅលើឧបករណ៍ទេ');
    }

    const targetDir = this.stagingDir || path.join(path.dirname(srcPath), '.staged');
    const stagedPath = path.join(targetDir, this._pendingUpdate.fileName);

    if (path.resolve(srcPath) !== path.resolve(stagedPath)) {
      await this._copyFileWithProgress(srcPath, stagedPath);
    } else {
      this.emit('download-progress', {
        percent: 100,
        transferredBytes: this._pendingUpdate.fileSize || 0,
        totalBytes: this._pendingUpdate.fileSize || 0,
      });
    }

    if (this.openFileFn) {
      const openErr = await this.openFileFn(stagedPath);
      if (openErr) {
        throw new Error(openErr);
      }
    }

    return {
      started: true,
      source: 'local-file',
      filePath: stagedPath,
      version: this._pendingUpdate.version,
    };
  }
}

module.exports = {
  UpdaterService,
  compareVersions,
  normalizeVersion,
};
