const crypto = require('node:crypto');
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { execFileSync } = require('node:child_process');

const LICENSE_SECRET = 'HONGGUO-BR-MINI-DOWNLOADER-2026-SECRET-KEY-V1';

const DURATION_PLANS = {
  '1m': { id: '1m', codePrefix: '1M', days: 30, labelKm: '1 ខែ (30 ថ្ងៃ)', labelEn: '1 Month' },
  '3m': { id: '3m', codePrefix: '3M', days: 90, labelKm: '3 ខែ (90 ថ្ងៃ)', labelEn: '3 Months' },
  '6m': { id: '6m', codePrefix: '6M', days: 180, labelKm: '6 ខែ (180 ថ្ងៃ)', labelEn: '6 Months' },
  '1y': { id: '1y', codePrefix: '1Y', days: 365, labelKm: '1 ឆ្នាំ (365 ថ្ងៃ)', labelEn: '1 Year' },
};

let cachedMachineId = null;

/**
 * Generates a deterministic Hardware PC ID unique to this computer.
 * Format: PC-XXXX-XXXX-XXXX
 */
function getMachineId() {
  if (cachedMachineId) return cachedMachineId;

  let rawGuid = '';
  if (process.platform === 'win32') {
    try {
      const out = execFileSync(
        'reg',
        ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
        { encoding: 'utf8', windowsHide: true, timeout: 4000 }
      );
      const match = /MachineGuid\s+REG_SZ\s+([^\r\n]+)/i.exec(out);
      if (match) rawGuid = match[1].trim();
    } catch {
      // Fallback to OS fingerprint below
    }
  }

  const cpus = os.cpus() || [];
  const cpuModel = cpus[0] ? cpus[0].model : 'generic-cpu';
  const fingerprintSource = [
    rawGuid,
    os.hostname(),
    os.platform(),
    os.arch(),
    cpuModel,
    String(cpus.length),
  ].join('|');

  const hash = crypto
    .createHmac('sha256', LICENSE_SECRET)
    .update(fingerprintSource)
    .digest('hex')
    .toUpperCase();

  cachedMachineId = `PC-${hash.slice(0, 4)}-${hash.slice(4, 8)}-${hash.slice(8, 12)}`;
  return cachedMachineId;
}

function normalizeKeyCode(raw) {
  return String(raw || '')
    .trim()
    .toUpperCase()
    .replace(/\s+/g, '');
}

function normalizeMachineId(raw) {
  return String(raw || '')
    .trim()
    .toUpperCase();
}

function signLicensePayload(keyCode, planId, targetMachineId = '') {
  const payload = `${normalizeKeyCode(keyCode)}|${planId}|${normalizeMachineId(targetMachineId)}`;
  return crypto
    .createHmac('sha256', LICENSE_SECRET)
    .update(payload)
    .digest('hex')
    .slice(0, 8)
    .toUpperCase();
}

function computeMachineTag(machineId) {
  return crypto
    .createHmac('sha256', `${LICENSE_SECRET}:PC-TAG`)
    .update(normalizeMachineId(machineId))
    .digest('hex')
    .slice(0, 4)
    .toUpperCase();
}

function verifyStandaloneKeySignature(keyCode, pcId) {
  const match = /^BR-(1M|3M|6M|1Y)-([0-9A-F]{4})-([0-9A-F]{4})-([0-9A-F]{4})$/i.exec(
    normalizeKeyCode(keyCode)
  );
  if (!match) return { valid: false };

  const prefix = match[1].toUpperCase();
  const randA = match[2].toUpperCase();
  const randB = match[3].toUpperCase();
  const sig = match[4].toUpperCase();

  const planEntry = Object.values(DURATION_PLANS).find((p) => p.codePrefix === prefix);
  if (!planEntry) return { valid: false };

  const baseCode = `BR-${prefix}-${randA}-${randB}`;
  const openSig = signLicensePayload(baseCode, planEntry.id, '').slice(0, 4);
  const boundSig = signLicensePayload(baseCode, planEntry.id, 'BOUND').slice(0, 4);
  const directPcSig = signLicensePayload(baseCode, planEntry.id, pcId).slice(0, 4);

  if (sig === boundSig) {
    const expectedPcTag = computeMachineTag(pcId);
    if (randB !== expectedPcTag) {
      return {
        valid: false,
        code: 'KEY_ALREADY_BOUND',
        error: 'កូដនេះត្រូវបានចាក់សោសម្រាប់តែកុំព្យូទ័រផ្សេងប៉ុណ្ណោះ! 1 កូដប្រើបានតែ 1 កុំព្យូទ័រ។',
      };
    }
    return { valid: true, planId: planEntry.id };
  }

  if (sig === openSig || sig === directPcSig) {
    return { valid: true, planId: planEntry.id };
  }

  return { valid: false };
}

function computeKeyStatus(record, nowMs = Date.now()) {
  if (!record) return 'invalid';
  if (record.revoked) return 'revoked';
  if (record.expiresAt) {
    const expMs = new Date(record.expiresAt).getTime();
    if (nowMs > expMs) return 'expired';
  }
  if (record.boundMachineId) return 'active';
  return 'unused';
}

function computeRemainingDays(record, nowMs = Date.now()) {
  if (!record) return 0;
  if (!record.expiresAt) {
    const plan = DURATION_PLANS[record.planId] || DURATION_PLANS['1m'];
    return plan.days;
  }
  const diffMs = new Date(record.expiresAt).getTime() - nowMs;
  if (diffMs <= 0) return 0;
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24));
}

function decorateLicenseRecord(record) {
  const nowMs = Date.now();
  const plan = DURATION_PLANS[record.planId] || DURATION_PLANS['1m'];
  const status = computeKeyStatus(record, nowMs);
  const remainingDays = computeRemainingDays(record, nowMs);
  return {
    ...record,
    planLabelKm: plan.labelKm,
    planLabelEn: plan.labelEn,
    planDays: plan.days,
    status,
    remainingDays,
  };
}

class LicenseService {
  constructor(options = {}) {
    this.dbPath =
      options.dbPath || path.join(path.resolve(__dirname, '..'), 'data', 'licenses.json');
    this.sessionPath = options.sessionPath || null;
    this.useGlobalPersistence = Boolean(options.useGlobalPersistence);
    this.machineId = options.machineId || getMachineId();
    this.remoteServerUrl = String(
      options.remoteServerUrl || process.env.HONGGUO_LICENSE_SERVER_URL || ''
    )
      .trim()
      .replace(/\/+$/, '');
    this._server = null;
  }

  getPlans() {
    return Object.values(DURATION_PLANS).map((p) => ({ ...p }));
  }

  _getSessionPaths() {
    const paths = [];
    if (this.sessionPath) paths.push(this.sessionPath);
    if (this.useGlobalPersistence) {
      paths.push(path.join(os.homedir(), '.hongguo-downloader', 'license-session.json'));
      const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
      paths.push(path.join(appData, 'hongguo-mini-downloader', 'license-session.json'));
      paths.push(path.join(appData, 'Hongguo Downloader', 'license-session.json'));
    }
    return Array.from(new Set(paths));
  }

  _getFallbackDbPaths() {
    const paths = [this.dbPath];
    if (this.useGlobalPersistence) {
      paths.push(path.join(os.homedir(), '.hongguo-downloader', 'licenses.json'));
      paths.push(path.join(path.resolve(__dirname, '..'), 'data', 'licenses.json'));
      paths.push('d:\\Honggou Download\\data\\licenses.json');
    }
    return Array.from(new Set(paths.filter(Boolean)));
  }

  async _loadDb() {
    const mergedByCode = new Map();
    for (const candidatePath of this._getFallbackDbPaths()) {
      try {
        if (!fs.existsSync(candidatePath)) continue;
        const raw = await fsp.readFile(candidatePath, 'utf8');
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.keys)) {
          for (const k of parsed.keys) {
            const norm = normalizeKeyCode(k && k.keyCode);
            if (norm && !mergedByCode.has(norm)) {
              mergedByCode.set(norm, k);
            }
          }
        }
      } catch {
        // Ignore unreadable candidate DB
      }
    }
    return { version: 1, keys: Array.from(mergedByCode.values()) };
  }

  async _saveDb(db) {
    await fsp.mkdir(path.dirname(this.dbPath), { recursive: true });
    const tmpPath = `${this.dbPath}.${process.pid}.${Date.now()}.tmp`;
    await fsp.writeFile(tmpPath, JSON.stringify(db, null, 2), 'utf8');
    await fsp.rename(tmpPath, this.dbPath);

    if (this.useGlobalPersistence) {
      const globalDbPath = path.join(os.homedir(), '.hongguo-downloader', 'licenses.json');
      if (path.resolve(globalDbPath) !== path.resolve(this.dbPath)) {
        try {
          await fsp.mkdir(path.dirname(globalDbPath), { recursive: true });
          await fsp.writeFile(globalDbPath, JSON.stringify(db, null, 2), 'utf8');
        } catch {
          // Ignore secondary backup error
        }
      }
    }
  }

  async _loadSession() {
    for (const p of this._getSessionPaths()) {
      try {
        if (!fs.existsSync(p)) continue;
        const raw = await fsp.readFile(p, 'utf8');
        const parsed = JSON.parse(raw);
        if (parsed && (parsed.keyCode || parsed.loggedOut)) {
          return parsed;
        }
      } catch {
        // Try next candidate path
      }
    }
    return null;
  }

  async _saveSession(sessionData) {
    for (const p of this._getSessionPaths()) {
      try {
        await fsp.mkdir(path.dirname(p), { recursive: true });
        await fsp.writeFile(p, JSON.stringify(sessionData, null, 2), 'utf8');
      } catch {
        // Ignore write error on secondary path
      }
    }
  }

  async clearSession() {
    const logoutMarker = { loggedOut: true, keyCode: null, updatedAt: new Date().toISOString() };
    for (const p of this._getSessionPaths()) {
      try {
        await fsp.mkdir(path.dirname(p), { recursive: true });
        await fsp.writeFile(p, JSON.stringify(logoutMarker, null, 2), 'utf8');
      } catch {
        // Ignore write error
      }
    }
  }

  /**
   * Generates a new 1-PC license key for 1m, 3m, 6m, or 1y.
   * If targetMachineId is provided, pre-binds the key to that PC ID immediately.
   * Otherwise, the key locks to the first PC that activates it.
   */
  async generateKey(options = {}) {
    const planId = DURATION_PLANS[options.planId] ? options.planId : '1m';
    const plan = DURATION_PLANS[planId];
    const targetMachineId = normalizeMachineId(options.targetMachineId || '');
    const note = String(options.note || '').trim();

    const randA = crypto.randomBytes(2).toString('hex').toUpperCase();
    const randB = targetMachineId
      ? computeMachineTag(targetMachineId)
      : crypto.randomBytes(2).toString('hex').toUpperCase();
    const baseCode = `BR-${plan.codePrefix}-${randA}-${randB}`;
    const sig = signLicensePayload(baseCode, planId, targetMachineId ? 'BOUND' : '').slice(0, 4);
    const keyCode = `${baseCode}-${sig}`;

    const nowIso = new Date().toISOString();
    const record = {
      keyCode,
      planId,
      createdAt: nowIso,
      activatedAt: null,
      expiresAt: null,
      boundMachineId: targetMachineId || null,
      preBoundMachineId: targetMachineId || null,
      revoked: false,
      note,
      lastCheckAt: null,
    };

    const db = await this._loadDb();
    db.keys.unshift(record);
    await this._saveDb(db);

    return decorateLicenseRecord(record);
  }

  async listKeys() {
    const db = await this._loadDb();
    return db.keys.map(decorateLicenseRecord);
  }

  /**
   * Activates or validates a license key for a specific PC (machineId).
   * Enforces:
   * - 1 Key = 1 PC (rejects if boundMachineId belongs to another PC)
   * - Expiration date (1M / 3M / 6M / 1Y from first activation)
   * - Revocation status
   */
  async activateKey(rawKeyCode, customMachineId = null) {
    const keyCode = normalizeKeyCode(rawKeyCode);
    const pcId = normalizeMachineId(customMachineId || this.machineId);

    if (!keyCode) {
      return {
        ok: false,
        code: 'EMPTY_KEY',
        error: 'សូមបញ្ចូលកូដអាជ្ញាប័ណ្ណ (License Key)!',
      };
    }

    // 1. Optional Remote Online License Server check
    if (this.remoteServerUrl && !this._server) {
      try {
        const res = await fetch(`${this.remoteServerUrl}/api/activate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ keyCode, machineId: pcId }),
          signal: AbortSignal.timeout(1500),
        });
        const remoteData = await res.json();
        if (remoteData && typeof remoteData.ok === 'boolean') {
          if (remoteData.ok && remoteData.license) {
            await this._saveSession({
              keyCode: remoteData.license.keyCode,
              machineId: pcId,
              activatedAt: remoteData.license.activatedAt,
              expiresAt: remoteData.license.expiresAt,
              planId: remoteData.license.planId,
            });
          }
          return remoteData;
        }
      } catch {
        // Fallback to local/cryptographic verification if remote server is unreachable
      }
    }

    const db = await this._loadDb();
    let record = db.keys.find((k) => normalizeKeyCode(k.keyCode) === keyCode);

    // 2. Standalone customer PC verification via cryptographic signature
    if (!record) {
      const sigCheck = verifyStandaloneKeySignature(keyCode, pcId);
      if (!sigCheck.valid) {
        return {
          ok: false,
          code: sigCheck.code || 'INVALID_KEY',
          error: sigCheck.error || 'កូដអាជ្ញាប័ណ្ណមិនត្រឹមត្រូវ ឬមិនមានក្នុងប្រព័ន្ធទេ!',
        };
      }
      record = {
        keyCode,
        planId: sigCheck.planId,
        createdAt: new Date().toISOString(),
        activatedAt: null,
        expiresAt: null,
        boundMachineId: pcId,
        preBoundMachineId: pcId,
        revoked: false,
        note: 'Activated on client PC',
        lastCheckAt: null,
      };
      db.keys.unshift(record);
    }

    if (record.revoked) {
      return {
        ok: false,
        code: 'KEY_REVOKED',
        error: 'កូដអាជ្ញាប័ណ្ណនេះត្រូវបានបិទ (Revoked) ដោយអ្នកគ្រប់គ្រង!',
      };
    }

    // Strict 1-PC check
    if (record.boundMachineId && normalizeMachineId(record.boundMachineId) !== pcId) {
      return {
        ok: false,
        code: 'KEY_ALREADY_BOUND',
        error: `កូដនេះត្រូវបានប្រើលើកុំព្យូទ័រផ្សេងរួចហើយ (${record.boundMachineId})! 1 កូដប្រើបានតែ 1 កុំព្យូទ័រ។`,
      };
    }

    const now = new Date();
    if (!record.activatedAt || !record.expiresAt) {
      const plan = DURATION_PLANS[record.planId] || DURATION_PLANS['1m'];
      record.activatedAt = now.toISOString();
      record.expiresAt = new Date(now.getTime() + plan.days * 24 * 60 * 60 * 1000).toISOString();
    }

    if (now.getTime() > new Date(record.expiresAt).getTime()) {
      await this._saveDb(db);
      return {
        ok: false,
        code: 'KEY_EXPIRED',
        error: `កូដអាជ្ញាប័ណ្ណនេះបានផុតកំណត់កាលពីថ្ងៃទី ${record.expiresAt.slice(0, 10)}!`,
      };
    }

    record.boundMachineId = pcId;
    record.lastCheckAt = now.toISOString();
    await this._saveDb(db);

    const decorated = decorateLicenseRecord(record);
    await this._saveSession({
      keyCode: record.keyCode,
      machineId: pcId,
      activatedAt: record.activatedAt,
      expiresAt: record.expiresAt,
      planId: record.planId,
    });

    return {
      ok: true,
      license: decorated,
    };
  }

  /**
   * Checks whether the current PC has an active, valid, non-expired license.
   */
  async getCurrentSessionStatus() {
    const pcId = normalizeMachineId(this.machineId);
    let session = await this._loadSession();

    if (session && session.loggedOut) {
      return {
        licensed: false,
        machineId: pcId,
        license: null,
      };
    }

    const db = await this._loadDb();

    // Auto-recover session if this PC already has an active bound key in the database
    if (!session || !session.keyCode) {
      const boundRecord = db.keys.find(
        (k) =>
          k &&
          normalizeMachineId(k.boundMachineId) === pcId &&
          !k.revoked &&
          (!k.expiresAt || new Date(k.expiresAt).getTime() > Date.now())
      );
      if (boundRecord) {
        session = {
          keyCode: boundRecord.keyCode,
          machineId: pcId,
          activatedAt: boundRecord.activatedAt,
          expiresAt: boundRecord.expiresAt,
          planId: boundRecord.planId,
        };
        await this._saveSession(session);
      } else {
        return {
          licensed: false,
          machineId: pcId,
          license: null,
        };
      }
    }

    // If session exists on this PC, ensure its record is preserved in local DB across app updates
    const normCode = normalizeKeyCode(session.keyCode);
    const existingRecord = db.keys.find((k) => normalizeKeyCode(k.keyCode) === normCode);
    if (!existingRecord && normalizeMachineId(session.machineId) === pcId && session.expiresAt) {
      db.keys.unshift({
        keyCode: normCode,
        planId: session.planId || '1m',
        createdAt: session.activatedAt || new Date().toISOString(),
        activatedAt: session.activatedAt || new Date().toISOString(),
        expiresAt: session.expiresAt,
        boundMachineId: pcId,
        preBoundMachineId: pcId,
        revoked: false,
        note: 'Restored from local PC session',
        lastCheckAt: new Date().toISOString(),
      });
      await this._saveDb(db);
    }

    const verifyRes = await this.activateKey(session.keyCode, pcId);
    if (!verifyRes.ok) {
      return {
        licensed: false,
        machineId: pcId,
        error: verifyRes.error,
        code: verifyRes.code,
        license: null,
      };
    }

    return {
      licensed: true,
      machineId: pcId,
      license: verifyRes.license,
    };
  }

  async unbindKey(rawKeyCode) {
    const keyCode = normalizeKeyCode(rawKeyCode);
    const db = await this._loadDb();
    const record = db.keys.find((k) => normalizeKeyCode(k.keyCode) === keyCode);
    if (!record) throw new Error('រកមិនឃើញកូដអាជ្ញាប័ណ្ណនេះទេ');
    record.boundMachineId = null;
    record.preBoundMachineId = null;
    await this._saveDb(db);
    return decorateLicenseRecord(record);
  }

  async toggleRevokeKey(rawKeyCode) {
    const keyCode = normalizeKeyCode(rawKeyCode);
    const db = await this._loadDb();
    const record = db.keys.find((k) => normalizeKeyCode(k.keyCode) === keyCode);
    if (!record) throw new Error('រកមិនឃើញកូដអាជ្ញាប័ណ្ណនេះទេ');
    record.revoked = !record.revoked;
    await this._saveDb(db);
    return decorateLicenseRecord(record);
  }

  async extendKey(rawKeyCode, planId = '1m') {
    const keyCode = normalizeKeyCode(rawKeyCode);
    const plan = DURATION_PLANS[planId] || DURATION_PLANS['1m'];
    const db = await this._loadDb();
    const record = db.keys.find((k) => normalizeKeyCode(k.keyCode) === keyCode);
    if (!record) throw new Error('រកមិនឃើញកូដអាជ្ញាប័ណ្ណនេះទេ');

    const nowMs = Date.now();
    const baseMs =
      record.expiresAt && new Date(record.expiresAt).getTime() > nowMs
        ? new Date(record.expiresAt).getTime()
        : nowMs;

    if (!record.activatedAt) {
      record.activatedAt = new Date(nowMs).toISOString();
    }
    record.expiresAt = new Date(baseMs + plan.days * 24 * 60 * 60 * 1000).toISOString();
    record.planId = plan.id;
    record.revoked = false;
    await this._saveDb(db);
    return decorateLicenseRecord(record);
  }

  async deleteKey(rawKeyCode) {
    const keyCode = normalizeKeyCode(rawKeyCode);
    const db = await this._loadDb();
    const idx = db.keys.findIndex((k) => normalizeKeyCode(k.keyCode) === keyCode);
    if (idx === -1) return false;
    db.keys.splice(idx, 1);
    await this._saveDb(db);
    return true;
  }

  /**
   * Starts a lightweight self-hosted HTTP License API Server (optional LAN/remote use)
   * on the specified port (default 4588).
   */
  startHttpServer(port = 4588) {
    if (this._server) return Promise.resolve(port);

    return new Promise((resolve) => {
      const server = http.createServer(async (req, res) => {
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

        if (req.method === 'OPTIONS') {
          res.writeHead(204);
          res.end();
          return;
        }

        if (req.method === 'GET' && req.url === '/api/health') {
          res.writeHead(200);
          res.end(JSON.stringify({ ok: true, service: 'hongguo-license-and-update-server' }));
          return;
        }

        // Serve online auto-update manifest (/update.json)
        if (req.method === 'GET' && req.url && req.url.startsWith('/update.json')) {
          const rootDir = path.resolve(__dirname, '..');
          const feedCandidates = [
            path.join(rootDir, 'updates', 'update.json'),
            path.join(rootDir, 'release', 'online-update-feed', 'update.json'),
          ];
          for (const candidate of feedCandidates) {
            if (fs.existsSync(candidate)) {
              try {
                const raw = await fsp.readFile(candidate, 'utf8');
                res.writeHead(200);
                res.end(raw);
                return;
              } catch {
                // Ignore read error
              }
            }
          }
          res.writeHead(404);
          res.end(JSON.stringify({ ok: false, error: 'No update.json published yet' }));
          return;
        }

        // Serve online auto-update binary files (/releases/<filename>)
        if (req.method === 'GET' && req.url && req.url.startsWith('/releases/')) {
          const safeName = path.basename(decodeURIComponent(req.url.slice('/releases/'.length)));
          const rootDir = path.resolve(__dirname, '..');
          const fileCandidates = [
            path.join(rootDir, 'updates', safeName),
            path.join(rootDir, 'release', 'online-update-feed', safeName),
            path.join(rootDir, 'release', safeName),
          ];
          for (const filePath of fileCandidates) {
            if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
              const stat = fs.statSync(filePath);
              res.writeHead(200, {
                'Content-Type': 'application/octet-stream',
                'Content-Length': stat.size,
                'Content-Disposition': `attachment; filename="${safeName}"`,
              });
              fs.createReadStream(filePath).pipe(res);
              return;
            }
          }
          res.writeHead(404);
          res.end(JSON.stringify({ ok: false, error: 'Release file not found' }));
          return;
        }

        if (req.method === 'POST' && req.url === '/api/activate') {
          let body = '';
          req.on('data', (chunk) => {
            body = (body + chunk.toString('utf8')).slice(0, 8192);
          });
          req.on('end', async () => {
            try {
              const parsed = JSON.parse(body || '{}');
              const result = await this.activateKey(parsed.keyCode, parsed.machineId);
              res.writeHead(result.ok ? 200 : 403);
              res.end(JSON.stringify(result));
            } catch (err) {
              res.writeHead(400);
              res.end(JSON.stringify({ ok: false, error: err.message }));
            }
          });
          return;
        }

        res.writeHead(404);
        res.end(JSON.stringify({ ok: false, error: 'Not Found' }));
      });

      server.on('error', () => {
        // Port already in use or unavailable
        resolve(null);
      });

      server.listen(port, '127.0.0.1', () => {
        this._server = server;
        resolve(port);
      });
    });
  }

  stopHttpServer() {
    if (this._server) {
      try {
        this._server.close();
      } catch {
        // Ignore close error
      }
      this._server = null;
    }
  }
}

module.exports = {
  LicenseService,
  DURATION_PLANS,
  getMachineId,
  normalizeKeyCode,
  normalizeMachineId,
};
