const { contextBridge, ipcRenderer } = require('electron');

function subscribe(channel, callback) {
  if (typeof callback !== 'function') return () => {};
  const listener = (_event, payload) => callback(payload);
  ipcRenderer.on(channel, listener);
  return () => ipcRenderer.removeListener(channel, listener);
}

contextBridge.exposeInMainWorld('hongguoAPI', {
  // Window controls
  minimizeWindow: () => ipcRenderer.invoke('window:minimize'),
  closeWindow: () => ipcRenderer.invoke('window:close'),
  toggleAlwaysOnTop: () => ipcRenderer.invoke('window:toggle-pin'),
  readClipboard: () => ipcRenderer.invoke('clipboard:read'),
  writeClipboard: (text) => ipcRenderer.invoke('clipboard:write', text),
  openExternalHongguo: (url) => ipcRenderer.invoke('shell:open-external', url),

  // License (1 PC = 1 Key)
  getLicenseStatus: () => ipcRenderer.invoke('license:status'),
  activateLicense: (keyCode) => ipcRenderer.invoke('license:activate', keyCode),
  logoutLicense: () => ipcRenderer.invoke('license:logout'),

  // Hongguo service
  getCategories: () => ipcRenderer.invoke('hongguo:categories'),
  getNewUpdateTypes: () => ipcRenderer.invoke('hongguo:new-update-types'),
  fetchNewUpdates: (type, cursor) => ipcRenderer.invoke('hongguo:new-updates', { type, cursor }),
  browseCategory: (categoryId, page) => ipcRenderer.invoke('hongguo:browse', { categoryId, page }),
  searchSeries: (query) => ipcRenderer.invoke('hongguo:search', query),
  fetchSeriesDetails: (input) => ipcRenderer.invoke('hongguo:fetch-series', input),

  // Downloads & Settings
  enqueueDownloads: (payload) => ipcRenderer.invoke('downloads:enqueue', payload),
  listDownloads: () => ipcRenderer.invoke('downloads:list'),
  cancelDownload: (taskId) => ipcRenderer.invoke('downloads:cancel', taskId),
  retryDownload: (taskId) => ipcRenderer.invoke('downloads:retry', taskId),
  cancelSeriesDownloads: (seriesId) => ipcRenderer.invoke('downloads:cancel-series', seriesId),
  retrySeriesDownloads: (seriesId) => ipcRenderer.invoke('downloads:retry-series', seriesId),
  clearFinishedDownloads: () => ipcRenderer.invoke('downloads:clear-finished'),
  openDownloadedFile: (filePath) => ipcRenderer.invoke('downloads:open-file', filePath),
  showInFolder: (filePath) => ipcRenderer.invoke('downloads:show-in-folder', filePath),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  chooseOutputDir: () => ipcRenderer.invoke('settings:choose-dir'),
  updateSettings: (partial) => ipcRenderer.invoke('settings:update', partial),

  // Auto-updater
  getUpdaterInfo: () => ipcRenderer.invoke('updater:get-info'),
  checkForUpdates: () => ipcRenderer.invoke('updater:check'),
  installUpdate: () => ipcRenderer.invoke('updater:install'),

  // Push events
  onDownloadProgress: (cb) => subscribe('download:progress', cb),
  onUpdateAvailable: (cb) => subscribe('updater:update-available', cb),
  onUpdateProgress: (cb) => subscribe('updater:progress', cb),
});
