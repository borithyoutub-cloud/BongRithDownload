const path = require('node:path');
const { LicenseService } = require('./license-service');

const PORT = Number(process.env.PORT) || 4588;
const ROOT_DIR = path.resolve(__dirname, '..');

async function startServer() {
  const svc = new LicenseService({
    dbPath: path.join(ROOT_DIR, 'data', 'licenses.json'),
  });

  // Bind to 0.0.0.0 so LAN / VPS / Tunnel clients can connect
  const http = require('node:http');
  const fs = require('node:fs');
  const fsp = require('node:fs/promises');

  const server = http.createServer(async (req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    if (req.method === 'GET' && req.url === '/api/health') {
      res.writeHead(200);
      res.end(JSON.stringify({ ok: true, service: 'hongguo-online-license-and-update-server' }));
      return;
    }

    if (req.method === 'POST' && req.url === '/api/activate') {
      let body = '';
      req.on('data', (chunk) => {
        body = (body + chunk.toString('utf8')).slice(0, 8192);
      });
      req.on('end', async () => {
        try {
          const parsed = JSON.parse(body || '{}');
          const result = await svc.activateKey(parsed.keyCode, parsed.machineId);
          res.writeHead(result.ok ? 200 : 403);
          res.end(JSON.stringify(result));
        } catch (err) {
          res.writeHead(400);
          res.end(JSON.stringify({ ok: false, error: err.message }));
        }
      });
      return;
    }

    if (req.method === 'GET' && req.url && req.url.startsWith('/update.json')) {
      const feedCandidates = [
        path.join(ROOT_DIR, 'updates', 'update.json'),
        path.join(ROOT_DIR, 'release', 'online-update-feed', 'update.json'),
      ];
      for (const candidate of feedCandidates) {
        if (fs.existsSync(candidate)) {
          const raw = await fsp.readFile(candidate, 'utf8');
          res.writeHead(200);
          res.end(raw);
          return;
        }
      }
      res.writeHead(404);
      res.end(JSON.stringify({ ok: false, error: 'No update.json found' }));
      return;
    }

    if (req.method === 'GET' && req.url && req.url.startsWith('/releases/')) {
      const safeName = path.basename(decodeURIComponent(req.url.slice('/releases/'.length)));
      const fileCandidates = [
        path.join(ROOT_DIR, 'updates', safeName),
        path.join(ROOT_DIR, 'release', 'online-update-feed', safeName),
        path.join(ROOT_DIR, 'release', safeName),
      ];
      for (const filePath of fileCandidates) {
        if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
          const stat = fs.statSync(filePath);
          res.writeHead(200, {
            'Content-Type': 'application/octet-stream',
            'Content-Length': stat.size,
            'Content-Disposition': `attachment; filename="${safeName}"`,
          });
          fs.createReadStream(filePath).pipe(res);
          return;
        }
      }
      res.writeHead(404);
      res.end(JSON.stringify({ ok: false, error: 'Release file not found' }));
      return;
    }

    res.writeHead(404);
    res.end(JSON.stringify({ ok: false, error: 'Not Found' }));
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log('==============================================================');
    console.log(` Hongguo Online License & Auto-Update Server Running on :${PORT}`);
    console.log('==============================================================');
    console.log(` • License Activation API : http://127.0.0.1:${PORT}/api/activate`);
    console.log(` • Auto-Update Feed URL   : http://127.0.0.1:${PORT}/update.json`);
    console.log(` • Release Files Endpoint : http://127.0.0.1:${PORT}/releases/<file>`);
    console.log('==============================================================');
  });
}

startServer();
